# ghs-telegram

Telegram bot untuk verifikasi GitHub Student dengan flow:
1. Login + 2FA
2. Auto update profile name + billing Indonesia/Banten (fresh per verifikasi)
3. Apply student (default kampus: Sultan Maulana Hasanuddin State Islamic University, Banten)
4. Submit `photo_proof` base64
5. Track status metadata tiap 1 menit sampai final

## Database
- Mendukung 2 engine:
  - SQLite lokal VPS: `data/ghs.sqlite`
  - Azure SQL Database (free limit students) via `database.engine = "sqlserver"`
- Data persistent:
  - coins
  - verifications / success / failed
  - referrals / earned
  - user profile metadata

## Azure SQL (Free Limit)
- Config ada di `src/config.js` -> `database.mssql`
- Engine aktif: `database.engine` (`sqlite` / `sqlserver`)
- Migrasi data SQLite ke Azure SQL:
```bash
node scripts/migrate-sqlite-to-sqlserver.mjs
```

## Test
- End-to-end datastore flow (engine aktif saat ini):
```bash
node scripts/test-e2e-flow.mjs
```
- End-to-end datastore flow lokal (paksa SQLite, tanpa Azure SQL):
```bash
TEST_DB_ENGINE=sqlite node scripts/test-e2e-flow.mjs
```
- Regression coin flow SQLite:
```bash
node scripts/test-coins-flow.mjs
```
- Proof autoflow check (generate + wiring + cleanup):
```bash
node scripts/test-proof-autoflow.mjs
```
- AUTO GHS end-to-end scenarios (approved + age reject + review reject):
```bash
node scripts/test-auto-ghs-e2e.mjs
```
- Cek isi data Azure SQL (users, coins, referrals):
```bash
node scripts/check-sqlserver-data.mjs
```
- Reset semua data Azure SQL (destructive):
```bash
node scripts/reset-sqlserver-data.mjs --yes
```
- Reset semua data SQLite (destructive):
```bash
node scripts/reset-sqlite-data.mjs --yes
# jika juga mau kosongkan data/users.json:
node scripts/reset-sqlite-data.mjs --yes --clear-json
```
- Tambah coins custom (id user + jumlah):
```bash
node scripts/addcoins.mjs 7472018171 100
# atau
node scripts/addcoins.mjs --user 7472018171 --amount 100
```

## UI
- Menu image + 3 tombol:
  - START VERIFICATION
  - REFERRALS
  - CONTACT SUPPORT
- Halaman referral teks + tombol `BACK TO MENU`

## Setup
1. Edit `src/config.js`
  - `telegramBotToken`
  - `ownerTelegramIds`
  - `supportUsername`
2. Install dependency:
```bash
npm install
```
3. Run bot:
```bash
npm start
```

## Command
- `/start`
- `/menu`
- `/ghs email,password,otp`

## Proof Otomatis
- Bot generate proof otomatis via `proof/genproof.js` setiap verifikasi `/ghs`
- Nama GitHub disinkronkan dari nama yang dihasilkan proof
- Sumber foto auto-mode diambil random dari: `proof/photo-pool/ready/`
- Jika tersedia `proof/photo-pool/manifest.json`, random foto akan mengikuti mapping gender (`male`/`female`)
- Nama akan dipilih dari file gender sesuai manifest:
  - `proof/name-male.txt`
  - `proof/name-female.txt`
- Jika file gender belum ada, otomatis fallback ke `proof/name.txt`
- Jika pool kosong/tidak valid, proses gagal (tanpa fallback)
- File proof sementara: `proof/idcard-output.png` dan otomatis dihapus setelah submit
