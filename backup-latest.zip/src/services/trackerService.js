import config from "../config.js";

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export default class TrackerService {
  constructor(githubService) {
    this.githubService = githubService;
  }

  async trackUntilFinal(session, metadataId, onUpdate = () => {}) {
    const max = config.polling.maxAttempts;
    for (let i = 1; i <= max; i += 1) {
      const now = await this.githubService.fetchMetadataStatus(session, metadataId);
      await onUpdate(now.state, i);
      if (now.state === "approved" || now.state === "rejected") return now.state;
      if (i < max) await sleep(config.polling.intervalMs);
    }
    return "pending";
  }
}
