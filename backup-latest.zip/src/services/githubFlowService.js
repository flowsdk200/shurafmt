import crypto from "crypto";
import fs from "fs";
import path from "path";
import axios from "axios";
import { wrapper as axiosCookieJarWrapper } from "axios-cookiejar-support";
import { CookieJar } from "tough-cookie";
import { load } from "cheerio";
import config from "../config.js";
import { createRequire } from "module";

const require = createRequire(import.meta.url);
const { Jimp } = require("jimp");

const clean = (v) => String(v || "").trim();
const nowStamp = () => new Date().toISOString().replace(/[:.]/g, "-");

const toAbsoluteUrl = (base, next) => {
  try {
    return new URL(next, base).toString();
  } catch {
    return clean(next);
  }
};

const base32Decode = (secret) => {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  let bits = "";
  const normalized = clean(secret).toUpperCase().replace(/=+$/g, "").replace(/[^A-Z2-7]/g, "");
  for (const ch of normalized) {
    const idx = alphabet.indexOf(ch);
    if (idx >= 0) bits += idx.toString(2).padStart(5, "0");
  }
  const out = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) out.push(parseInt(bits.slice(i, i + 8), 2));
  return Buffer.from(out);
};

export const generateTotp = (secret, digits = 6, period = 30) => {
  const key = base32Decode(secret);
  const counter = Math.floor(Date.now() / 1000 / period);
  const counterBuf = Buffer.alloc(8);
  counterBuf.writeUInt32BE(Math.floor(counter / 0x100000000), 0);
  counterBuf.writeUInt32BE(counter >>> 0, 4);
  const digest = crypto.createHmac("sha1", key).update(counterBuf).digest();
  const offset = digest[digest.length - 1] & 0x0f;
  const code =
    ((digest[offset] & 0x7f) << 24) |
    ((digest[offset + 1] & 0xff) << 16) |
    ((digest[offset + 2] & 0xff) << 8) |
    (digest[offset + 3] & 0xff);
  return String(code % 10 ** digits).padStart(digits, "0");
};

const resolveOtpCode = (otpInput) => {
  const raw = clean(otpInput);
  if (!raw) throw new Error("OTP is required.");
  // If user already provides a 6-digit code, use it directly.
  if (/^\d{6}$/.test(raw)) return raw;
  // Otherwise treat as TOTP secret.
  return generateTotp(raw);
};

const parseForm = ($, baseUrl, actionPart) => {
  const form = $("form")
    .filter((_, el) => clean($(el).attr("action")).includes(actionPart))
    .first();
  if (!form.length) return null;

  const fields = {};
  form.find("input,textarea,select").each((_, el) => {
    const node = $(el);
    const name = clean(node.attr("name"));
    if (!name) return;
    const tag = (el.tagName || "").toLowerCase();
    if (tag === "select") {
      const selected = node.find("option[selected]").first();
      const fallback = node.find("option").first();
      fields[name] = clean(
        selected.attr("value") || selected.text() || fallback.attr("value") || fallback.text()
      );
      return;
    }
    const type = clean(node.attr("type")).toLowerCase();
    if (["submit", "button", "image", "reset", "file"].includes(type)) return;
    if ((type === "checkbox" || type === "radio") && !node.attr("checked")) return;
    fields[name] = clean(node.attr("value") || node.text());
  });

  return {
    action: toAbsoluteUrl(baseUrl, clean(form.attr("action"))),
    fields
  };
};

const parseFormByInputNames = ($, baseUrl, inputNames = []) => {
  const wanted = new Set(inputNames.map((x) => clean(x)).filter(Boolean));
  const form = $("form")
    .filter((_, el) => {
      const node = $(el);
      let found = false;
      node.find("input,textarea,select").each((__, field) => {
        const n = clean($(field).attr("name"));
        if (wanted.has(n)) found = true;
      });
      return found;
    })
    .first();
  if (!form.length) return null;

  const action = clean(form.attr("action")) || baseUrl;
  const fields = {};
  form.find("input,textarea,select").each((_, el) => {
    const node = $(el);
    const name = clean(node.attr("name"));
    if (!name) return;
    const tag = (el.tagName || "").toLowerCase();
    if (tag === "select") {
      const selected = node.find("option[selected]").first();
      const fallback = node.find("option").first();
      fields[name] = clean(
        selected.attr("value") || selected.text() || fallback.attr("value") || fallback.text()
      );
      return;
    }
    const type = clean(node.attr("type")).toLowerCase();
    if (["submit", "button", "image", "reset", "file"].includes(type)) return;
    if ((type === "checkbox" || type === "radio") && !node.attr("checked")) return;
    fields[name] = clean(node.attr("value") || node.text());
  });

  return { action: toAbsoluteUrl(baseUrl, action), fields };
};

const pickMetadataIds = (html) =>
  [...new Set(String(html || "").match(/\/settings\/education\/developer_pack_applications\/metadata\/\d+/g) || [])];

const parseMetadataState = (html) => {
  const txt = String(html || "").replace(/\s+/g, " ");
  if (/application approved|has been approved/i.test(txt)) return "approved";
  if (/application rejected|unable to verify|not eligible|we were unfortunately not able to verify/i.test(txt))
    return "rejected";
  if (/currently pending review|under review|application has been submitted|has been received/i.test(txt))
    return "pending";
  return "unknown";
};

const parseRejectedReason = (html = "") => {
  const $ = load(html || "");
  const reasons = [];
  const isGenericReason = (text) => {
    const t = clean(text).toLowerCase();
    if (!t) return true;
    return [
      /visit our edu community/.test(t),
      /faq(?:s)? and tips/.test(t),
      /learn more/.test(t),
      /need help/.test(t),
      /contact support/.test(t),
      /terms of service/.test(t),
      /privacy statement/.test(t),
      /github education/.test(t)
    ].some(Boolean);
  };

  $("li").each((_, el) => {
    const txt = clean($(el).text().replace(/\s+/g, " "));
    if (!txt) return;
    if (isGenericReason(txt)) return;
    if (txt.length < 20) return;
    reasons.push(txt);
  });

  if (reasons.length) return reasons[0];

  const bodyText = clean($( "body").text().replace(/\s+/g, " "));
  const m = bodyText.match(
    /we were unfortunately not able to verify[\s\S]*?please address the following issues and apply again\.\s*([\s\S]{20,300}?)(?:visit our edu community|footer|$)/i
  );
  if (m?.[1]) {
    const candidate = clean(m[1]);
    if (candidate && !isGenericReason(candidate)) return candidate;
  }

  return "";
};


const extractRejectedDiagnostics = (html = "") => {
  const $ = load(html || "");
  const bullets = [];

  $("li").each((_, el) => {
    const txt = clean($(el).text().replace(/\s+/g, " "));
    if (!txt) return;
    if (txt.length < 12) return;
    bullets.push(txt);
  });

  const bodyText = clean($("body").text().replace(/\s+/g, " "));
  const aroundReject =
    bodyText.match(/we were unfortunately not able to verify[\s\S]{0,500}/i)?.[0] || "";

  return {
    bullets: [...new Set(bullets)].slice(0, 10),
    aroundReject: clean(aroundReject),
    textLength: bodyText.length
  };
};

const parseUsernameFromProfileHtml = (html = "") => {
  const $ = load(html || "");

  const byMeta =
    clean($('meta[name="user-login"]').attr("content")) ||
    clean($('meta[name="octolytics-actor-login"]').attr("content"));
  if (/^[A-Za-z0-9-]+$/.test(byMeta)) return byMeta;

  const form = $("form")
    .filter((_, el) => clean($(el).attr("action")).includes("/users/"))
    .first();
  if (form.length) {
    const action = clean(form.attr("action"));
    const m = action.match(/\/users\/([^/?#]+)/i);
    const byForm = clean(m?.[1] || "");
    if (/^[A-Za-z0-9-]+$/.test(byForm)) return byForm;
  }

  return "";
};

const parseJoinedAtFromProfileHtml = (html = "") => {
  const $ = load(html || "");
  let joinedIso = "";

  $("relative-time[datetime]").each((_, el) => {
    if (joinedIso) return;
    const node = $(el);
    const parentText = clean(node.parent().text());
    const around = clean(node.closest("*").text());
    if (/joined/i.test(parentText) || /joined/i.test(around)) {
      joinedIso = clean(node.attr("datetime"));
    }
  });

  if (!joinedIso) {
    const joinedAttr =
      clean($(".join-date relative-time").first().attr("datetime")) ||
      clean($("li[itemprop='joinDate'] relative-time").first().attr("datetime"));
    if (joinedAttr) joinedIso = joinedAttr;
  }

  if (!joinedIso) {
    const joinedFromText = clean($(".join-date").first().text().replace(/\s+/g, " "));
    const m = joinedFromText.match(/Joined\s+([A-Za-z]{3,9}\s+\d{1,2},\s+\d{4})/i);
    const txt = clean(m?.[1] || "");
    if (txt) {
      const asDate = new Date(`${txt} 00:00:00 UTC`);
      if (!Number.isNaN(asDate.getTime())) return asDate;
    }
  }

  if (!joinedIso) {
    const m = String(html || "").match(/Joined[\s\S]{0,240}?datetime="([^"]+)"/i);
    joinedIso = clean(m?.[1] || "");
  }

  if (!joinedIso) {
    const joinedText = clean((String(html || "").match(/Joined\s+([A-Za-z]{3}\s+\d{1,2},\s+\d{4})/i) || [])[1]);
    if (joinedText) {
      const asDate = new Date(`${joinedText} 00:00:00 UTC`);
      if (!Number.isNaN(asDate.getTime())) return asDate;
    }
  }

  if (!joinedIso) return null;
  const dt = new Date(joinedIso);
  if (Number.isNaN(dt.getTime())) return null;
  return dt;
};

const parseProfileNameFromSettingsHtml = (html = "") => {
  const $ = load(html || "");
  const byName =
    clean($('input[name="user[profile_name]"]').attr("value")) ||
    clean($('input[name="user_profile_name"]').attr("value")) ||
    clean($('input[name="user[name]"]').attr("value")) ||
    clean($("#user_profile_name").attr("value"));
  return byName;
};

const parsePublicProfileName = (html = "") => {
  const $ = load(html || "");
  const v =
    clean($('span[itemprop="name"]').first().text()) ||
    clean($("h1 .p-name").first().text()) ||
    clean($("h1.vcard-names .p-name").first().text());
  return v;
};

const parseProfileUpdateIssue = (html = "") => {
  const $ = load(html || "");
  const candidates = [
    ".flash-error",
    ".flash-full.flash-error",
    ".js-flash-alert",
    ".js-flash-error",
    ".error",
    ".form-group.errored .error",
    ".FormControl-inlineValidation"
  ];
  for (const selector of candidates) {
    const txt = clean($(selector).first().text().replace(/\s+/g, " "));
    if (txt) return txt;
  }
  const body = clean($("body").text().replace(/\s+/g, " "));
  const m =
    body.match(/(cannot|invalid|failed|error)[^.]{0,180}\./i) ||
    body.match(/(there was a problem[^.]{0,220}\.)/i);
  return clean(m?.[1] || "");
};

const resolveProofUploadMeta = (proofPathInput = "") => {
  const rawPath = clean(proofPathInput);
  const extRaw = clean(path.extname(rawPath)).toLowerCase();
  const ext =
    extRaw === ".png" || extRaw === ".jpg" || extRaw === ".jpeg" || extRaw === ".webp"
      ? extRaw
      : ".jpg";

  let mimeType = "image/jpeg";
  if (ext === ".png") mimeType = "image/png";
  else if (ext === ".webp") mimeType = "image/webp";

  const filename = `id-card${ext}`;
  return { filename, mimeType };
};

const normalizeProofForUpload = async ({ idCardBuffer, idCardPath = "" }) => {
  const fallback = {
    idCardBuffer,
    idCardPath,
    uploadMeta: resolveProofUploadMeta(idCardPath)
  };

  try {
    const image = await Jimp.fromBuffer(idCardBuffer);
    const srcW = Number(image.width) || 0;
    const srcH = Number(image.height) || 0;
    if (!srcW || !srcH) return fallback;

    const jpegBuffer = await image.getBuffer("image/jpeg", { quality: 72 });
    const normalizedPath = clean(idCardPath).replace(/\.[^.]+$/i, "") || "id-card";
    return {
      idCardBuffer: jpegBuffer,
      idCardPath: `${normalizedPath}.jpg`,
      uploadMeta: { filename: "id-card.jpg", mimeType: "image/jpeg" }
    };
  } catch {
    return fallback;
  }
};

export default class GithubFlowService {
  constructor() {
    this.base = config.github.baseUrl;
    this.debugEnabled = Boolean(config.debug?.enabled);
    this.debugDir = path.resolve(config.debug?.dir || "./debug");
    this.saveHtml = Boolean(config.debug?.saveHtml);
    if (this.debugEnabled && !fs.existsSync(this.debugDir)) fs.mkdirSync(this.debugDir, { recursive: true });
  }

  debugLog(step, payload = {}, html = "") {
    if (!this.debugEnabled) return;
    const stamp = nowStamp();
    const base = `${stamp}_${step}`;
    const jsonPath = path.join(this.debugDir, `${base}.json`);
    const safePayload = { step, at: new Date().toISOString(), ...payload };
    fs.writeFileSync(jsonPath, JSON.stringify(safePayload, null, 2));
    if (this.saveHtml && clean(html)) {
      const htmlPath = path.join(this.debugDir, `${base}.html`);
      fs.writeFileSync(htmlPath, String(html));
    }
  }

  createSession() {
    const jar = new CookieJar();
    const client = axiosCookieJarWrapper(
      axios.create({
        jar,
        withCredentials: true,
        timeout: 45_000,
        maxRedirects: 10,
        validateStatus: () => true,
        headers: {
          "User-Agent": config.github.userAgent,
          "Accept-Language": "en-US,en;q=0.9"
        }
      })
    );
    return { jar, client };
  }

  async get(session, url, headers = {}) {
    const res = await session.client.get(url, { headers });
    return {
      status: Number(res.status) || 0,
      url: clean(res.request?.res?.responseUrl || url),
      html: typeof res.data === "string" ? res.data : String(res.data || "")
    };
  }

  async postForm(session, url, fields, referer = "", turbo = true) {
    const body = new URLSearchParams();
    for (const [k, v] of Object.entries(fields || {})) {
      if (!clean(k)) continue;
      if (v === undefined || v === null) continue;
      body.append(k, String(v));
    }
    const res = await session.client.post(url, body.toString(), {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Accept: turbo
          ? "text/vnd.turbo-stream.html, text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
          : "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        Origin: this.base,
        ...(referer ? { Referer: referer } : {})
      }
    });
    return {
      status: Number(res.status) || 0,
      url: clean(res.request?.res?.responseUrl || url),
      html: typeof res.data === "string" ? res.data : String(res.data || "")
    };
  }

  async loginWith2fa(session, { email, password, otp }) {
    const loginPage = await this.get(session, `${this.base}/login`);
    this.debugLog("login_page", { url: loginPage.url, status: loginPage.status }, loginPage.html);
    const $ = load(loginPage.html);
    const loginForm = parseForm($, loginPage.url, "/session");
    if (!loginForm) throw new Error("Login form not found.");
    this.debugLog("login_form_parsed", { action: loginForm.action, keys: Object.keys(loginForm.fields || {}) });

    const loginFields = { ...loginForm.fields, login: clean(email), password: clean(password) };
    if (loginFields.commit === undefined) loginFields.commit = "Sign in";
    const loginResp = await this.postForm(session, `${this.base}/session`, loginFields, loginPage.url, false);
    this.debugLog("login_submit_resp", { url: loginResp.url, status: loginResp.status }, loginResp.html);

    if (
      loginResp.url.includes("/sessions/verified-device") ||
      /device verification code|verified-device|we just sent your authentication code via email/i.test(loginResp.html)
    ) {
      throw new Error("GitHub device verification required.");
    }

    if (loginResp.url.includes("/sessions/two-factor") || /name="app_otp"|name="otp"/.test(loginResp.html)) {
      const $otp = load(loginResp.html);
      const otpForm = parseForm($otp, loginResp.url, "/sessions/two-factor");
      if (!otpForm) throw new Error("2FA form not found.");
      this.debugLog("otp_form_parsed", { action: otpForm.action, keys: Object.keys(otpForm.fields || {}) }, loginResp.html);

      const otpFields = { ...otpForm.fields };
      const code = resolveOtpCode(otp);
      if (Object.prototype.hasOwnProperty.call(otpFields, "app_otp") || /app_otp/.test(loginResp.html)) {
        otpFields.app_otp = code;
      } else {
        otpFields.otp = code;
      }
      const otpResp = await this.postForm(session, otpForm.action, otpFields, loginResp.url, false);
      this.debugLog("otp_submit_resp", { url: otpResp.url, status: otpResp.status }, otpResp.html);
      if (
        otpResp.url.includes("/sessions/verified-device") ||
        /device verification code|verified-device|we just sent your authentication code via email/i.test(otpResp.html)
      ) {
        throw new Error("GitHub device verification required.");
      }
      if (otpResp.url.includes("/sessions/two-factor") || /Incorrect code|Incorrect one-time password/i.test(otpResp.html)) {
        throw new Error("OTP verification failed.");
      }
    } else if (loginResp.url.includes("/login")) {
      throw new Error("Login failed.");
    }
  }

  async checkAccountAgeAtLeastDays(session, minDays = 3) {
    const min = Math.max(0, Number(minDays) || 0);
    const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    const settingsProfile = await this.get(session, `${this.base}/settings/profile`, {
      Referer: `${this.base}/`
    });
    this.debugLog(
      "agecheck_settings_profile",
      {
        status: settingsProfile.status,
        url: settingsProfile.url
      },
      settingsProfile.html
    );
    const username = parseUsernameFromProfileHtml(settingsProfile.html);
    if (!username) {
      throw new Error(
        `Failed to read GitHub username. status=${settingsProfile.status} url=${settingsProfile.url}`
      );
    }

    let joinedAt = null;
    let lastStatus = 0;
    let lastError = "";
    const attempts = 3;
    for (let i = 0; i < attempts; i += 1) {
      try {
        const apiResp = await session.client.get(`https://api.github.com/users/${username}`, {
          headers: {
            Accept: "application/vnd.github+json",
            Referer: `${this.base}/settings/profile`
          }
        });
        lastStatus = Number(apiResp?.status) || 0;
        const createdAtRaw = clean(apiResp?.data?.created_at);
        const fromApi = createdAtRaw ? new Date(createdAtRaw) : null;
        this.debugLog("agecheck_user_api", {
          username,
          status: lastStatus,
          createdAt: createdAtRaw,
          source: "api",
          attempt: i + 1
        });

        if (fromApi && !Number.isNaN(fromApi.getTime())) {
          joinedAt = fromApi;
          break;
        }
        lastError = "missing created_at";
      } catch (e) {
        lastStatus = Number(e?.response?.status) || 0;
        lastError = clean(e?.message || "api failed");
        this.debugLog("agecheck_user_api", {
          username,
          status: lastStatus,
          source: "api",
          error: lastError,
          attempt: i + 1
        });
      }

      if (i < attempts - 1) await wait(800);
    }

    if (!joinedAt) {
      throw new Error(
        `Failed to read GitHub account age from API. username=${username} status=${lastStatus || 0}${
          lastError ? ` error=${lastError}` : ""
        }`
      );
    }

    const ageMs = Date.now() - joinedAt.getTime();
    const ageDays = Math.floor(ageMs / (24 * 60 * 60 * 1000));
    const ok = ageDays >= min;
    return { ok, username, ageDays, joinedAt };
  }

  async updateProfileName(session, fullName) {
    const targetName = clean(fullName);
    if (!targetName) throw new Error("Invalid profile name.");
    let lastProfileIssue = "";

    const applyNameToKnownFields = (fields = {}) => {
      const next = { ...fields };
      const keys = ["user[profile_name]", "user_profile_name", "user[name]", "profile_name"];
      let touched = false;
      for (const key of keys) {
        if (Object.prototype.hasOwnProperty.call(next, key)) {
          next[key] = targetName;
          touched = true;
        }
      }
      if (!touched) next["user[profile_name]"] = targetName;
      return next;
    };

    const pickSafeProfileFields = (fields = {}) => {
      const safe = {};
      const keepExact = [
        "_method",
        "authenticity_token",
        "timestamp",
        "timestamp_secret",
        "commit",
        "user[profile_name]",
        "user_profile_name",
        "user[name]",
        "profile_name"
      ];
      for (const key of keepExact) {
        if (Object.prototype.hasOwnProperty.call(fields, key)) safe[key] = fields[key];
      }
      for (const [k, v] of Object.entries(fields || {})) {
        if (/^required_field_\d+$/i.test(clean(k))) safe[k] = clean(v);
      }
      if (!Object.keys(safe).some((k) => /user\[profile_name\]|user_profile_name|user\[name\]|profile_name/.test(k))) {
        safe["user[profile_name]"] = targetName;
      }
      return applyNameToKnownFields(safe);
    };

    const verifyApplied = async (referer) => {
      const settingsResp = await this.get(session, `${this.base}/settings/profile`, {
        Referer: referer || `${this.base}/settings/profile`
      });
      const settingsName = parseProfileNameFromSettingsHtml(settingsResp.html);
      const username = parseUsernameFromProfileHtml(settingsResp.html);
      let publicName = "";
      if (username) {
        const publicResp = await this.get(session, `${this.base}/${username}`, {
          Referer: `${this.base}/settings/profile`
        });
        publicName = parsePublicProfileName(publicResp.html);
      }
      const ok = clean(settingsName) === targetName || clean(publicName) === targetName;
      return { ok, settingsName, publicName };
    };

    const profile = await this.get(session, `${this.base}/settings/profile`, { Referer: `${this.base}/` });
    this.debugLog("settings_profile_page", { url: profile.url, status: profile.status, targetName }, profile.html);
    const $ = load(profile.html);

    const trySubmit = async (form) => {
      if (!form) return false;
      try {
        this.debugLog("profile_form_try", { action: form.action, keys: Object.keys(form.fields || {}), targetName });
        const fields = pickSafeProfileFields(form.fields);
        const submitResp = await this.postForm(session, form.action, fields, profile.url, false);
        this.debugLog(
          "profile_submit_resp",
          { action: form.action, url: submitResp.url, status: submitResp.status, targetName },
          submitResp.html
        );
        lastProfileIssue = parseProfileUpdateIssue(submitResp.html) || lastProfileIssue;
        const check = await verifyApplied(profile.url);
        this.debugLog("profile_verify_after_submit", {
          targetName,
          ok: check.ok,
          settingsName: clean(check.settingsName),
          publicName: clean(check.publicName)
        });
        return check.ok;
      } catch {
        return false;
      }
    };

    // Strategy 1: primary user profile form (/users/:username)
    const formUser = parseForm($, profile.url, "/users/");
    if (await trySubmit(formUser)) return true;

    // Strategy 2: fallback profile settings form (/settings/profile)
    const formSettings = parseForm($, profile.url, "/settings/profile");
    if (await trySubmit(formSettings)) return true;

    // Strategy 3: detect any form that contains profile-name related fields
    const formByField = parseFormByInputNames($, profile.url, [
      "user[profile_name]",
      "user_profile_name",
      "user[name]",
      "profile_name"
    ]);
    if (await trySubmit(formByField)) return true;

    // Strategy 4: direct fallback submit to /settings/profile
    try {
      const token =
        clean($('input[name="authenticity_token"]').first().attr("value")) ||
        clean($('meta[name="csrf-token"]').attr("content"));
      if (token) {
        const fields = {
          authenticity_token: token,
          _method: "put",
          "user[profile_name]": targetName
        };
        const submitResp = await this.postForm(session, `${this.base}/settings/profile`, fields, profile.url, false);
        this.debugLog(
          "profile_direct_settings_profile_submit_resp",
          { url: submitResp.url, status: submitResp.status, targetName },
          submitResp.html
        );
        lastProfileIssue = parseProfileUpdateIssue(submitResp.html) || lastProfileIssue;
        const check = await verifyApplied(profile.url);
        this.debugLog("profile_direct_settings_profile", {
          targetName,
          ok: check.ok,
          settingsName: clean(check.settingsName),
          publicName: clean(check.publicName)
        });
        if (check.ok) return true;
      }
    } catch {
      // keep trying next strategy
    }

    // Strategy 5: direct fallback submit to /settings/profile/name_update
    try {
      const token =
        clean($('input[name="authenticity_token"]').first().attr("value")) ||
        clean($('meta[name="csrf-token"]').attr("content"));
      if (token) {
        const fields = {
          authenticity_token: token,
          "user[profile_name]": targetName
        };
        const submitResp = await this.postForm(
          session,
          `${this.base}/settings/profile/name_update`,
          fields,
          profile.url,
          false
        );
        this.debugLog(
          "profile_direct_name_update_submit_resp",
          { url: submitResp.url, status: submitResp.status, targetName },
          submitResp.html
        );
        lastProfileIssue = parseProfileUpdateIssue(submitResp.html) || lastProfileIssue;
        const check = await verifyApplied(profile.url);
        this.debugLog("profile_direct_name_update", {
          targetName,
          ok: check.ok,
          settingsName: clean(check.settingsName),
          publicName: clean(check.publicName)
        });
        if (check.ok) return true;
      }
    } catch {
      // fall through to final error
    }

    const finalCheck = await verifyApplied(profile.url).catch(() => ({
      ok: false,
      settingsName: "",
      publicName: ""
    }));
    this.debugLog("profile_final_failed", {
      targetName,
      settingsName: clean(finalCheck.settingsName),
      publicName: clean(finalCheck.publicName)
    });
    const issue = clean(lastProfileIssue);
    throw new Error(
      `Profile name update failed. target="${targetName}", settings="${clean(finalCheck.settingsName)}", public="${clean(finalCheck.publicName)}"${issue ? `, issue="${issue}"` : ""}`
    );
  }

  async updateBilling(session, { firstName, lastName, address1 = "" }) {
    const billing = await this.get(session, `${this.base}/settings/billing/payment_information`, {
      Referer: `${this.base}/settings/profile`
    });
    const $ = load(billing.html);
    const form = parseForm($, billing.url, "/account/contact");
    if (!form) throw new Error("Billing form not found.");

    form.fields["billing_contact[first_name]"] = clean(firstName);
    form.fields["billing_contact[last_name]"] = clean(lastName);
    form.fields["billing_contact[address1]"] = clean(address1) || clean(config.github.billing.address1);
    form.fields["billing_contact[address2]"] = clean(config.github.billing.address2);
    form.fields["billing_contact[city]"] = clean(config.github.billing.city);
    form.fields["billing_contact[country_code]"] = clean(config.github.billing.countryCode);
    form.fields["billing_contact[region]"] = clean(config.github.billing.region);
    form.fields["billing_contact[postal_code]"] = clean(config.github.billing.postalCode);
    form.fields.vat_code = clean(config.github.billing.vatCode);

    await this.postForm(session, form.action, form.fields, billing.url, false);
  }

  async openApplyForm(session) {
    const page = await this.get(session, `${this.base}/settings/education/developer_pack_applications/new`, {
      "Turbo-Frame": "dev-pack-form",
      Referer: `${this.base}/settings/education/benefits`
    });
    const $ = load(page.html);
    const form = parseForm($, page.url, "/settings/education/developer_pack_applications");
    if (!form) throw new Error("Application form not found.");
    return { page, form };
  }

  async continueStudentApplication(session, { email }) {
    const { page, form } = await this.openApplyForm(session);
    const school = config.github.school;
    const location = config.github.location;
    const payload = {
      ...form.fields,
      "dev_pack_form[application_type]": "student",
      "dev_pack_form[school_name]": school.name,
      "dev_pack_form[school_email]": clean(email),
      "dev_pack_form[selected_school_id]": school.id,
      "dev_pack_form[camera_required]": school.cameraRequired,
      "dev_pack_form[email_domains]": school.emailDomains,
      "dev_pack_form[override_distance_limit]": school.overrideDistanceLimit,
      "dev_pack_form[two_factor_required]": school.twoFactorRequired,
      "dev_pack_form[user_too_far_from_school]": school.userTooFarFromSchool,
      "dev_pack_form[new_school]": "false",
      "dev_pack_form[location_shared]": "true",
      "dev_pack_form[latitude]": location.latitude,
      "dev_pack_form[longitude]": location.longitude,
      "dev_pack_form[browser_location]": location.browserLocation,
      continue: "Continue"
    };
    const step2 = await this.postForm(
      session,
      `${this.base}/settings/education/developer_pack_applications`,
      payload,
      page.url
    );
    const $step2 = load(step2.html);
    const form2 = parseForm($step2, step2.url, "/settings/education/developer_pack_applications");
    if (!form2 || !Object.prototype.hasOwnProperty.call(form2.fields, "dev_pack_form[photo_proof]")) {
      throw new Error("photo_proof upload form did not appear.");
    }
    return { step2, form2 };
  }

  async submitPhotoProof(session, { email, idCardBuffer, idCardPath = "" }) {
    const { step2, form2 } = await this.continueStudentApplication(session, { email });
    const normalized = await normalizeProofForUpload({ idCardBuffer, idCardPath });
    const uploadMeta = normalized.uploadMeta;
    const photoProof = JSON.stringify({
      image: `data:${uploadMeta.mimeType};base64,${normalized.idCardBuffer.toString("base64")}`,
      metadata: {
        filename: uploadMeta.filename,
        type: "upload",
        mimeType: uploadMeta.mimeType,
        deviceLabel: ""
      }
    });
    const payload = {
      ...form2.fields,
      "dev_pack_form[proof_type]": form2.fields["dev_pack_form[proof_type]"] || "1. Dated school ID",
      "dev_pack_form[photo_proof]": photoProof
    };
    const submitResp = await this.postForm(
      session,
      `${this.base}/settings/education/developer_pack_applications`,
      payload,
      step2.url
    );

    return submitResp;
  }

  async findLatestMetadataId(session) {
    const benefits = await this.get(session, `${this.base}/settings/education/benefits`, {
      Referer: `${this.base}/settings/education/developer_pack_applications/new`
    });
    const ids = pickMetadataIds(benefits.html);
    if (!ids.length) return null;
    return ids[0].split("/").pop();
  }

  async fetchMetadataStatus(session, metadataId) {
    const url = `${this.base}/settings/education/developer_pack_applications/metadata/${clean(metadataId)}`;
    const resp = await this.get(session, url, {
      Referer: `${this.base}/settings/education/benefits`
    });
    const state = parseMetadataState(resp.html);
    this.debugLog(
      `metadata_status_${clean(metadataId)}_${state}`,
      { metadataId: clean(metadataId), state, status: resp.status, url: resp.url },
      resp.html
    );
    return {
      state,
      html: resp.html
    };
  }

  extractRejectedReason(html = "") {
    return parseRejectedReason(html);
  }

  extractRejectedDiagnostics(html = "") {
    return extractRejectedDiagnostics(html);
  }
}
