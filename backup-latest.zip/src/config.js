import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "..");
const fromProjectRoot = (p) => path.resolve(projectRoot, p);

const config = {
  telegramBotToken: "8425759595:AAEF0O5-Zo3SRxTXE00RcsqYrXFTvZMs0sg",
  ownerTelegramIds: [7472018171],
  ownerDefaultCoins: 5000,
  supportUsername: "riflowsxz",
  accessGate: {
    requiredJoin: {
      enabled: true,
      chatId: "@githubverifychat",
      url: "https://t.me/githubverifychat"
    }
  },
  verification: {
    minAccountAgeDays: 3
  },
  database: {
    engine: "sqlite", // sqlite | sqlserver
    mssql: {
      server: "ghstgsqll2lzkm.database.windows.net",
      port: 1433,
      database: "ghstelegram",
      user: "ghsadmin",
      password: "SAGoBGnrh0a@_8D5Dz++JJoT",
      connectionTimeoutMs: 120000,
      requestTimeoutMs: 120000,
      connectRetry: {
        maxAttempts: 6,
        delayMs: 5000
      },
      options: {
        encrypt: true,
        trustServerCertificate: false
      },
      pool: {
        max: 10,
        min: 0,
        idleTimeoutMillis: 30000
      }
    }
  },
  github: {
    baseUrl: "https://github.com",
    userAgent:
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    school: {
      name: "Sultan Maulana Hasanuddin State Islamic University, Banten",
      id: "51966",
      cameraRequired: "true",
      emailDomains: "[[\"uinbanten.ac.id\",false,\"MIXED_USE\",\"DENYLISTED\"]]",
      overrideDistanceLimit: "false",
      twoFactorRequired: "false",
      userTooFarFromSchool: "false"
    },
    location: {
      browserLocation:
        "UIN Sultan Maulana Hasanuddin Banten, Jalan Jendral Sudirman No. 30, Panancangan, Cipocok Jaya, Kota Serang, Banten 42118, Indonesia",
      latitude: "-6.121313",
      longitude: "106.1736272"
    },
    billing: {
      countryCode: "ID",
      region: "Banten",
      city: "Serang",
      address1: "Jl. Sudirman",
      addressFilePath: fromProjectRoot("proof/address.txt"),
      address2: "",
      postalCode: "42111",
      vatCode: ""
    }
  },
  polling: {
    intervalMs: 60_000,
    maxAttempts: 180
  },
  debug: {
    enabled: true,
    dir: fromProjectRoot("debug"),
    saveHtml: true,
    verificationLogMaxEntries: 50000
  },
  storage: {
    sqliteFile: fromProjectRoot("data/ghs.sqlite"),
    usersJsonFile: fromProjectRoot("data/users.json"),
    menuImagePath: fromProjectRoot("data/thumbnail.jpg"),
    verificationLogsPath: fromProjectRoot("data/logs.json")
  }
};

export default config;
