import fs from "fs";
import path from "path";
import sql from "mssql";
import config from "../config.js";

const DEFAULT_USER_COINS = 5;
const OWNER_DEFAULT_COINS = 5000;

const clean = (v) => String(v || "").trim();

const toUserRow = (row) => {
  if (!row) return null;
  return {
    user_id: clean(row.user_id),
    tg_name: clean(row.tg_name),
    tg_username: clean(row.tg_username),
    coins: Number(row.coins) || 0,
    verifications: Number(row.verifications) || 0,
    success: Number(row.success) || 0,
    failed: Number(row.failed) || 0,
    referrals: Number(row.referrals) || 0,
    earned: Number(row.earned) || 0,
    referred_by: clean(row.referred_by),
    created_at: Number(row.created_at) || 0,
    updated_at: Number(row.updated_at) || 0
  };
};

export default class SqlServerStore {
  constructor(dbConfig = config.database?.mssql, usersJsonPath = config.storage.usersJsonFile) {
    const cfg = dbConfig && typeof dbConfig === "object" ? dbConfig : {};
    if (!cfg.server || !cfg.database || !cfg.user || !cfg.password) {
      throw new Error("SQL Server config is incomplete in src/config.js (database.mssql)");
    }

    this.usersJsonPath = path.resolve(usersJsonPath || "./data/users.json");
    this.usersJsonMtimeMs = 0;
    this.cfg = cfg;
    this.pool = new sql.ConnectionPool({
      server: clean(cfg.server),
      port: Number(cfg.port) || 1433,
      database: clean(cfg.database),
      user: clean(cfg.user),
      password: String(cfg.password || ""),
      connectionTimeout: Number(cfg.connectionTimeoutMs) || 120_000,
      requestTimeout: Number(cfg.requestTimeoutMs) || 120_000,
      options: {
        encrypt: cfg.options?.encrypt !== false,
        trustServerCertificate: Boolean(cfg.options?.trustServerCertificate)
      },
      pool: {
        max: Number(cfg.pool?.max) || 10,
        min: Number(cfg.pool?.min) || 0,
        idleTimeoutMillis: Number(cfg.pool?.idleTimeoutMillis) || 30_000
      }
    });
    this.poolPromise = this.pool.connect();
    this.ready = this._init();
  }

  async _reconnectWithRetry() {
    const maxAttempts = Math.max(1, Number(this.cfg.connectRetry?.maxAttempts) || 6);
    const delayMs = Math.max(1000, Number(this.cfg.connectRetry?.delayMs) || 5000);

    let lastErr = null;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        this.poolPromise = this.pool.connect();
        await this.poolPromise;
        return;
      } catch (e) {
        lastErr = e;
        if (attempt < maxAttempts) {
          await new Promise((resolve) => setTimeout(resolve, delayMs));
        }
      }
    }
    throw lastErr || new Error("Failed to reconnect SQL Server pool");
  }

  async _request() {
    try {
      const pool = await this.poolPromise;
      return pool.request();
    } catch {
      await this._reconnectWithRetry();
      const pool = await this.poolPromise;
      return pool.request();
    }
  }

  _isOwner(userId) {
    return (config.ownerTelegramIds || []).map((x) => String(x)).includes(String(userId));
  }

  _ownerTargetCoins() {
    const n = Number(config.ownerDefaultCoins);
    return Number.isFinite(n) && n > 0 ? Math.floor(n) : OWNER_DEFAULT_COINS;
  }

  async _runInTransaction(work) {
    const pool = await this.poolPromise;
    const tx = new sql.Transaction(pool);
    await tx.begin();
    try {
      const result = await work(tx);
      await tx.commit();
      return result;
    } catch (e) {
      try {
        await tx.rollback();
      } catch {
        // ignore rollback errors
      }
      throw e;
    }
  }

  async _init() {
    const req = await this._request();
    await req.batch(`
      IF OBJECT_ID(N'users', N'U') IS NULL
      BEGIN
        CREATE TABLE users (
          user_id NVARCHAR(64) NOT NULL PRIMARY KEY,
          tg_name NVARCHAR(255) NOT NULL CONSTRAINT DF_users_tg_name DEFAULT N'',
          tg_username NVARCHAR(255) NOT NULL CONSTRAINT DF_users_tg_username DEFAULT N'',
          coins INT NOT NULL CONSTRAINT DF_users_coins DEFAULT 5,
          verifications INT NOT NULL CONSTRAINT DF_users_verifications DEFAULT 0,
          success INT NOT NULL CONSTRAINT DF_users_success DEFAULT 0,
          failed INT NOT NULL CONSTRAINT DF_users_failed DEFAULT 0,
          referrals INT NOT NULL CONSTRAINT DF_users_referrals DEFAULT 0,
          earned INT NOT NULL CONSTRAINT DF_users_earned DEFAULT 0,
          referred_by NVARCHAR(64) NOT NULL CONSTRAINT DF_users_referred_by DEFAULT N'',
          created_at BIGINT NOT NULL,
          updated_at BIGINT NOT NULL
        );
      END;

      IF OBJECT_ID(N'referrals', N'U') IS NULL
      BEGIN
        CREATE TABLE referrals (
          id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
          referrer_id NVARCHAR(64) NOT NULL,
          referred_id NVARCHAR(64) NOT NULL UNIQUE,
          created_at BIGINT NOT NULL
        );
      END;
    `);

    await this._normalizeOwnerRoleCoinsAll();
    await this._hydrateUsersFromJson();
    await this._normalizeOwnerRoleCoinsAll();
    await this._syncUsersToJson();
  }

  async _normalizeOwnerRoleCoinsAll() {
    const req = await this._request();
    const rows = (await req.query("SELECT user_id, coins FROM users")).recordset || [];
    if (!rows.length) return;
    const now = Date.now();

    await this._runInTransaction(async (tx) => {
      for (const row of rows) {
        const userId = clean(row.user_id);
        if (!userId) continue;
        const coins = Number(row.coins) || 0;
        const owner = this._isOwner(userId);
        let target = null;
        const ownerCoins = this._ownerTargetCoins();
        if (owner && coins !== ownerCoins) target = ownerCoins;
        else if (!owner && coins === 2) target = DEFAULT_USER_COINS;
        else if (!owner && (coins === ownerCoins || coins > ownerCoins)) target = DEFAULT_USER_COINS;
        if (target === null) continue;

        const r = new sql.Request(tx);
        r.input("coins", sql.Int, target);
        r.input("updated_at", sql.BigInt, now);
        r.input("user_id", sql.NVarChar(64), userId);
        await r.query("UPDATE users SET coins = @coins, updated_at = @updated_at WHERE user_id = @user_id");
      }
    });
  }

  async _pullUsersJsonIfChanged() {
    if (!this.usersJsonPath || !fs.existsSync(this.usersJsonPath)) return;
    const stat = fs.statSync(this.usersJsonPath);
    const mtimeMs = Number(stat.mtimeMs) || 0;
    if (mtimeMs <= this.usersJsonMtimeMs) return;
    await this._hydrateUsersFromJson();
    this.usersJsonMtimeMs = mtimeMs;
  }

  async _hydrateUsersFromJson() {
    if (!this.usersJsonPath || !fs.existsSync(this.usersJsonPath)) return;
    let parsed;
    try {
      parsed = JSON.parse(fs.readFileSync(this.usersJsonPath, "utf8"));
    } catch {
      return;
    }

    const usersMap = parsed && typeof parsed === "object" ? parsed.users : null;
    if (!usersMap || typeof usersMap !== "object") return;
    const now = Date.now();

    await this._runInTransaction(async (tx) => {
      for (const [userIdRaw, u] of Object.entries(usersMap)) {
        const userId = clean(userIdRaw);
        if (!userId) continue;
        const row = u && typeof u === "object" ? u : {};
        const createdAt = Number(row.created_at) > 0 ? Number(row.created_at) : now;

        const req = new sql.Request(tx);
        req.input("user_id", sql.NVarChar(64), userId);
        req.input("tg_name", sql.NVarChar(255), clean(row.tg_name));
        req.input("tg_username", sql.NVarChar(255), clean(row.tg_username));
        req.input("coins", sql.Int, Math.max(0, Number(row.coins) || 0));
        req.input("verifications", sql.Int, Math.max(0, Number(row.verifications) || 0));
        req.input("success", sql.Int, Math.max(0, Number(row.success) || 0));
        req.input("failed", sql.Int, Math.max(0, Number(row.failed) || 0));
        req.input("referrals", sql.Int, Math.max(0, Number(row.referrals) || 0));
        req.input("earned", sql.Int, Math.max(0, Number(row.earned) || 0));
        req.input("referred_by", sql.NVarChar(64), clean(row.referred_by));
        req.input("created_at", sql.BigInt, createdAt);
        req.input("updated_at", sql.BigInt, now);

        await req.query(`
          MERGE users AS target
          USING (SELECT @user_id AS user_id) AS source
          ON target.user_id = source.user_id
          WHEN MATCHED THEN
            UPDATE SET
              tg_name = @tg_name,
              tg_username = @tg_username,
              coins = @coins,
              verifications = @verifications,
              success = @success,
              failed = @failed,
              referrals = @referrals,
              earned = @earned,
              referred_by = @referred_by,
              updated_at = @updated_at
          WHEN NOT MATCHED THEN
            INSERT (
              user_id, tg_name, tg_username, coins, verifications, success,
              failed, referrals, earned, referred_by, created_at, updated_at
            )
            VALUES (
              @user_id, @tg_name, @tg_username, @coins, @verifications, @success,
              @failed, @referrals, @earned, @referred_by, @created_at, @updated_at
            );
        `);
      }
    });
  }

  async _syncUsersToJson() {
    if (!this.usersJsonPath) return;
    const dir = path.dirname(this.usersJsonPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    const req = await this._request();
    const rows = (await req.query("SELECT * FROM users ORDER BY user_id ASC")).recordset || [];
    const users = {};

    for (const row of rows) {
      const u = toUserRow(row);
      users[u.user_id] = {
        tg_name: u.tg_name,
        tg_username: u.tg_username,
        coins: u.coins,
        verifications: u.verifications,
        success: u.success,
        failed: u.failed,
        referrals: u.referrals,
        earned: u.earned,
        referred_by: u.referred_by,
        created_at: u.created_at,
        updated_at: u.updated_at
      };
    }

    fs.writeFileSync(this.usersJsonPath, JSON.stringify({ users }, null, 2));
    this.usersJsonMtimeMs = Number(fs.statSync(this.usersJsonPath).mtimeMs) || this.usersJsonMtimeMs;
  }

  async ensureUser(user) {
    await this.ready;
    await this._pullUsersJsonIfChanged();

    const userId = clean(user?.id);
    if (!userId) throw new Error("Invalid user id");

    const now = Date.now();
    const tgName = clean(user?.full_name || [user?.first_name, user?.last_name].filter(Boolean).join(" "));
    const tgUsername = clean(user?.username);
    const existing = await this.getUser(userId);

    if (!existing) {
      const coins = this._isOwner(userId) ? this._ownerTargetCoins() : DEFAULT_USER_COINS;
      const req = await this._request();
      req.input("user_id", sql.NVarChar(64), userId);
      req.input("tg_name", sql.NVarChar(255), tgName);
      req.input("tg_username", sql.NVarChar(255), tgUsername);
      req.input("coins", sql.Int, coins);
      req.input("created_at", sql.BigInt, now);
      req.input("updated_at", sql.BigInt, now);
      await req.query(`
        INSERT INTO users (
          user_id, tg_name, tg_username, coins, verifications, success, failed,
          referrals, earned, referred_by, created_at, updated_at
        ) VALUES (
          @user_id, @tg_name, @tg_username, @coins, 0, 0, 0, 0, 0, N'', @created_at, @updated_at
        )
      `);
    } else {
      const req = await this._request();
      req.input("user_id", sql.NVarChar(64), userId);
      req.input("tg_name", sql.NVarChar(255), tgName);
      req.input("tg_username", sql.NVarChar(255), tgUsername);
      req.input("updated_at", sql.BigInt, now);

      const ownerCoins = this._ownerTargetCoins();
      if (this._isOwner(userId) && Number(existing.coins) !== ownerCoins) {
        req.input("coins", sql.Int, ownerCoins);
        await req.query(`
          UPDATE users
          SET coins = @coins, tg_name = @tg_name, tg_username = @tg_username, updated_at = @updated_at
          WHERE user_id = @user_id
        `);
      } else if (!this._isOwner(userId) && Number(existing.coins) >= ownerCoins) {
        req.input("coins", sql.Int, DEFAULT_USER_COINS);
        await req.query(`
          UPDATE users
          SET coins = @coins, tg_name = @tg_name, tg_username = @tg_username, updated_at = @updated_at
          WHERE user_id = @user_id
        `);
      } else {
        await req.query(`
          UPDATE users
          SET tg_name = @tg_name, tg_username = @tg_username, updated_at = @updated_at
          WHERE user_id = @user_id
        `);
      }
    }

    await this._syncUsersToJson();
    return this.getUser(userId);
  }

  async getUser(userId) {
    await this.ready;
    const req = await this._request();
    req.input("user_id", sql.NVarChar(64), clean(userId));
    const rs = await req.query("SELECT TOP 1 * FROM users WHERE user_id = @user_id");
    return toUserRow(rs.recordset?.[0]);
  }

  async incrementVerifications(userId) {
    await this.ready;
    const req = await this._request();
    req.input("updated_at", sql.BigInt, Date.now());
    req.input("user_id", sql.NVarChar(64), clean(userId));
    await req.query("UPDATE users SET verifications = verifications + 1, updated_at = @updated_at WHERE user_id = @user_id");
    await this._syncUsersToJson();
  }

  async incrementSuccess(userId) {
    await this.ready;
    const req = await this._request();
    req.input("updated_at", sql.BigInt, Date.now());
    req.input("user_id", sql.NVarChar(64), clean(userId));
    await req.query("UPDATE users SET success = success + 1, updated_at = @updated_at WHERE user_id = @user_id");
    await this._syncUsersToJson();
  }

  async incrementFailed(userId) {
    await this.ready;
    const req = await this._request();
    req.input("updated_at", sql.BigInt, Date.now());
    req.input("user_id", sql.NVarChar(64), clean(userId));
    await req.query("UPDATE users SET failed = failed + 1, updated_at = @updated_at WHERE user_id = @user_id");
    await this._syncUsersToJson();
  }

  async deductCoins(userId, amount = 1) {
    await this.ready;
    const cost = Math.max(1, Number(amount) || 1);
    const req = await this._request();
    req.input("cost", sql.Int, cost);
    req.input("updated_at", sql.BigInt, Date.now());
    req.input("user_id", sql.NVarChar(64), clean(userId));
    const rs = await req.query(`
      UPDATE users
      SET coins = coins - @cost, updated_at = @updated_at
      WHERE user_id = @user_id AND coins >= @cost;
    `);
    const changed = Number(rs.rowsAffected?.[0] || 0);
    if (!changed) return false;
    await this._syncUsersToJson();
    return true;
  }

  async deductOneCoin(userId) {
    return this.deductCoins(userId, 1);
  }

  async addCoins(userId, amount) {
    await this.ready;
    const n = Math.max(0, Number(amount) || 0);
    if (!n) return;
    const req = await this._request();
    req.input("coins", sql.Int, n);
    req.input("updated_at", sql.BigInt, Date.now());
    req.input("user_id", sql.NVarChar(64), clean(userId));
    await req.query("UPDATE users SET coins = coins + @coins, updated_at = @updated_at WHERE user_id = @user_id");
    await this._syncUsersToJson();
  }

  async applyReferral({ referrerId, newUserId }) {
    await this.ready;
    const a = clean(referrerId);
    const b = clean(newUserId);
    if (!a || !b || a === b) return false;

    const referred = await this.getUser(b);
    const referrer = await this.getUser(a);
    if (!referred || !referrer) return false;
    if (clean(referred.referred_by)) return false;

    const now = Date.now();
    try {
      const ok = await this._runInTransaction(async (tx) => {
        const checkReq = new sql.Request(tx);
        checkReq.input("referred_id", sql.NVarChar(64), b);
        const exists = await checkReq.query("SELECT TOP 1 referred_id FROM referrals WHERE referred_id = @referred_id");
        if (exists.recordset?.length) return false;

        const insertReq = new sql.Request(tx);
        insertReq.input("referrer_id", sql.NVarChar(64), a);
        insertReq.input("referred_id", sql.NVarChar(64), b);
        insertReq.input("created_at", sql.BigInt, now);
        await insertReq.query(
          "INSERT INTO referrals (referrer_id, referred_id, created_at) VALUES (@referrer_id, @referred_id, @created_at)"
        );

        const updateReferrerReq = new sql.Request(tx);
        updateReferrerReq.input("updated_at", sql.BigInt, now);
        updateReferrerReq.input("user_id", sql.NVarChar(64), a);
        await updateReferrerReq.query(`
          UPDATE users
          SET referrals = referrals + 1,
              earned = earned + 1,
              coins = coins + 1,
              updated_at = @updated_at
          WHERE user_id = @user_id
        `);

        const updateReferredReq = new sql.Request(tx);
        updateReferredReq.input("referred_by", sql.NVarChar(64), a);
        updateReferredReq.input("updated_at", sql.BigInt, now);
        updateReferredReq.input("user_id", sql.NVarChar(64), b);
        await updateReferredReq.query(
          "UPDATE users SET referred_by = @referred_by, updated_at = @updated_at WHERE user_id = @user_id"
        );

        return true;
      });

      if (!ok) return false;
      await this._syncUsersToJson();
      return true;
    } catch (e) {
      if ([2627, 2601].includes(Number(e?.number))) return false;
      throw e;
    }
  }
}
