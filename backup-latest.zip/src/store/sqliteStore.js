import fs from "fs";
import path from "path";
import Database from "better-sqlite3";
import config from "../config.js";

const DEFAULT_USER_COINS = 5;
const OWNER_DEFAULT_COINS = 5000;

const clean = (v) => String(v || "").trim();

export default class SqliteStore {
  constructor(filePath = config.storage.sqliteFile, usersJsonPath = config.storage.usersJsonFile) {
    const abs = path.resolve(filePath);
    const dir = path.dirname(abs);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    this.usersJsonPath = path.resolve(usersJsonPath || "./data/users.json");
    this.usersJsonMtimeMs = 0;
    this.db = new Database(abs);
    this.db.pragma("journal_mode = WAL");
    this._init();
  }

  _init() {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS users (
        user_id TEXT PRIMARY KEY,
        tg_name TEXT NOT NULL DEFAULT '',
        tg_username TEXT NOT NULL DEFAULT '',
        coins INTEGER NOT NULL DEFAULT 5,
        verifications INTEGER NOT NULL DEFAULT 0,
        success INTEGER NOT NULL DEFAULT 0,
        failed INTEGER NOT NULL DEFAULT 0,
        referrals INTEGER NOT NULL DEFAULT 0,
        earned INTEGER NOT NULL DEFAULT 0,
        referred_by TEXT NOT NULL DEFAULT '',
        created_at INTEGER NOT NULL,
        updated_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS referrals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        referrer_id TEXT NOT NULL,
        referred_id TEXT NOT NULL UNIQUE,
        created_at INTEGER NOT NULL
      );
    `);
    this._migrateUsersTable();
    this._normalizeOwnerRoleCoinsAll();
    this._hydrateUsersFromJson();
    this._normalizeOwnerRoleCoinsAll();
    this._syncUsersToJson();
  }

  _migrateUsersTable() {
    const columns = this.db.prepare("PRAGMA table_info(users)").all();
    const hasLegacyIdCard = columns.some((c) => String(c.name) === "id_card_file_id");
    if (!hasLegacyIdCard) return;

    const trx = this.db.transaction(() => {
      this.db.exec(`
        CREATE TABLE IF NOT EXISTS users_new (
          user_id TEXT PRIMARY KEY,
          tg_name TEXT NOT NULL DEFAULT '',
          tg_username TEXT NOT NULL DEFAULT '',
          coins INTEGER NOT NULL DEFAULT 5,
          verifications INTEGER NOT NULL DEFAULT 0,
          success INTEGER NOT NULL DEFAULT 0,
          failed INTEGER NOT NULL DEFAULT 0,
          referrals INTEGER NOT NULL DEFAULT 0,
          earned INTEGER NOT NULL DEFAULT 0,
          referred_by TEXT NOT NULL DEFAULT '',
          created_at INTEGER NOT NULL,
          updated_at INTEGER NOT NULL
        );
      `);

      this.db.exec(`
        INSERT OR REPLACE INTO users_new (
          user_id, tg_name, tg_username, coins, verifications, success, failed,
          referrals, earned, referred_by, created_at, updated_at
        )
        SELECT
          user_id, tg_name, tg_username, coins, verifications, success, failed,
          referrals, earned, referred_by, created_at, updated_at
        FROM users;
      `);

      this.db.exec("DROP TABLE users;");
      this.db.exec("ALTER TABLE users_new RENAME TO users;");
    });

    trx();
  }

  _isOwner(userId) {
    return (config.ownerTelegramIds || []).map((x) => String(x)).includes(String(userId));
  }

  _ownerTargetCoins() {
    const n = Number(config.ownerDefaultCoins);
    return Number.isFinite(n) && n > 0 ? Math.floor(n) : OWNER_DEFAULT_COINS;
  }

  _normalizeOwnerRoleCoinsAll() {
    const rows = this.db.prepare("SELECT user_id, coins FROM users").all();
    if (!rows.length) return;
    const now = Date.now();
    const setCoins = this.db.prepare("UPDATE users SET coins = ?, updated_at = ? WHERE user_id = ?");

    const trx = this.db.transaction(() => {
      for (const row of rows) {
        const userId = String(row.user_id || "");
        const coins = Number(row.coins) || 0;
        const owner = this._isOwner(userId);
        const ownerCoins = this._ownerTargetCoins();
        if (owner && coins !== ownerCoins) {
          setCoins.run(ownerCoins, now, userId);
        } else if (!owner && coins === 2) {
          setCoins.run(DEFAULT_USER_COINS, now, userId);
        } else if (!owner && (coins === ownerCoins || coins > ownerCoins)) {
          setCoins.run(DEFAULT_USER_COINS, now, userId);
        }
      }
    });
    trx();
  }

  _pullUsersJsonIfChanged() {
    if (!this.usersJsonPath || !fs.existsSync(this.usersJsonPath)) return;
    const stat = fs.statSync(this.usersJsonPath);
    const mtimeMs = Number(stat.mtimeMs) || 0;
    if (mtimeMs <= this.usersJsonMtimeMs) return;
    this._hydrateUsersFromJson();
    this.usersJsonMtimeMs = mtimeMs;
  }

  _hydrateUsersFromJson() {
    if (!this.usersJsonPath || !fs.existsSync(this.usersJsonPath)) return;
    let parsed;
    try {
      parsed = JSON.parse(fs.readFileSync(this.usersJsonPath, "utf8"));
    } catch {
      return;
    }
    const usersMap = parsed && typeof parsed === "object" ? parsed.users : null;
    if (!usersMap || typeof usersMap !== "object") return;

    const now = Date.now();
    const upsert = this.db.prepare(`
      INSERT INTO users (
        user_id, tg_name, tg_username, coins, verifications, success, failed,
        referrals, earned, referred_by, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(user_id) DO UPDATE SET
        tg_name = excluded.tg_name,
        tg_username = excluded.tg_username,
        coins = excluded.coins,
        verifications = excluded.verifications,
        success = excluded.success,
        failed = excluded.failed,
        referrals = excluded.referrals,
        earned = excluded.earned,
        referred_by = excluded.referred_by,
        updated_at = excluded.updated_at
    `);

    const trx = this.db.transaction(() => {
      for (const [userIdRaw, u] of Object.entries(usersMap)) {
        const userId = String(userIdRaw || "").trim();
        if (!userId) continue;
        const row = u && typeof u === "object" ? u : {};
        const createdAt = Number(row.created_at) > 0 ? Number(row.created_at) : now;
        upsert.run(
          userId,
          clean(row.tg_name),
          clean(row.tg_username),
          Math.max(0, Number(row.coins) || 0),
          Math.max(0, Number(row.verifications) || 0),
          Math.max(0, Number(row.success) || 0),
          Math.max(0, Number(row.failed) || 0),
          Math.max(0, Number(row.referrals) || 0),
          Math.max(0, Number(row.earned) || 0),
          clean(row.referred_by),
          createdAt,
          now
        );
      }
    });

    trx();
  }

  _syncUsersToJson() {
    if (!this.usersJsonPath) return;
    const dir = path.dirname(this.usersJsonPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const rows = this.db.prepare("SELECT * FROM users ORDER BY user_id ASC").all();
    const users = {};
    for (const row of rows) {
      users[String(row.user_id)] = {
        tg_name: clean(row.tg_name),
        tg_username: clean(row.tg_username),
        coins: Number(row.coins) || 0,
        verifications: Number(row.verifications) || 0,
        success: Number(row.success) || 0,
        failed: Number(row.failed) || 0,
        referrals: Number(row.referrals) || 0,
        earned: Number(row.earned) || 0,
        referred_by: clean(row.referred_by),
        created_at: Number(row.created_at) || 0,
        updated_at: Number(row.updated_at) || 0
      };
    }
    fs.writeFileSync(this.usersJsonPath, JSON.stringify({ users }, null, 2));
    this.usersJsonMtimeMs = Number(fs.statSync(this.usersJsonPath).mtimeMs) || this.usersJsonMtimeMs;
  }

  ensureUser(user) {
    this._pullUsersJsonIfChanged();
    const userId = String(user?.id || "");
    if (!userId) throw new Error("Invalid user id");
    const now = Date.now();
    const tgName = clean(user?.full_name || [user?.first_name, user?.last_name].filter(Boolean).join(" "));
    const tgUsername = clean(user?.username || "");

    const existing = this.db
      .prepare("SELECT * FROM users WHERE user_id = ?")
      .get(userId);

    if (!existing) {
      const coins = this._isOwner(userId) ? this._ownerTargetCoins() : DEFAULT_USER_COINS;
      this.db
        .prepare(`
          INSERT INTO users (
            user_id, tg_name, tg_username, coins, verifications, success, failed,
            referrals, earned, referred_by, created_at, updated_at
          ) VALUES (?, ?, ?, ?, 0, 0, 0, 0, 0, '', ?, ?)
        `)
        .run(userId, tgName, tgUsername, coins, now, now);
    } else {
      // Keep owner/user role and coins in sync with config changes.
      const ownerCoins = this._ownerTargetCoins();
      if (this._isOwner(userId) && Number(existing.coins) !== ownerCoins) {
        this.db
          .prepare("UPDATE users SET coins = ?, tg_name = ?, tg_username = ?, updated_at = ? WHERE user_id = ?")
          .run(ownerCoins, tgName, tgUsername, now, userId);
      } else if (!this._isOwner(userId) && Number(existing.coins) >= ownerCoins) {
        this.db
          .prepare("UPDATE users SET coins = ?, tg_name = ?, tg_username = ?, updated_at = ? WHERE user_id = ?")
          .run(DEFAULT_USER_COINS, tgName, tgUsername, now, userId);
      } else {
        this.db
          .prepare("UPDATE users SET tg_name = ?, tg_username = ?, updated_at = ? WHERE user_id = ?")
          .run(tgName, tgUsername, now, userId);
      }
    }
    this._syncUsersToJson();
    return this.getUser(userId);
  }

  getUser(userId) {
    return this.db.prepare("SELECT * FROM users WHERE user_id = ?").get(String(userId));
  }

  incrementVerifications(userId) {
    this.db
      .prepare("UPDATE users SET verifications = verifications + 1, updated_at = ? WHERE user_id = ?")
      .run(Date.now(), String(userId));
    this._syncUsersToJson();
  }

  incrementSuccess(userId) {
    this.db
      .prepare("UPDATE users SET success = success + 1, updated_at = ? WHERE user_id = ?")
      .run(Date.now(), String(userId));
    this._syncUsersToJson();
  }

  incrementFailed(userId) {
    this.db
      .prepare("UPDATE users SET failed = failed + 1, updated_at = ? WHERE user_id = ?")
      .run(Date.now(), String(userId));
    this._syncUsersToJson();
  }

  deductCoins(userId, amount = 1) {
    const cost = Math.max(1, Number(amount) || 1);
    const u = this.getUser(userId);
    if (!u) return false;
    if (Number(u.coins) < cost) return false;
    this.db
      .prepare("UPDATE users SET coins = coins - ?, updated_at = ? WHERE user_id = ?")
      .run(cost, Date.now(), String(userId));
    this._syncUsersToJson();
    return true;
  }

  deductOneCoin(userId) {
    return this.deductCoins(userId, 1);
  }

  addCoins(userId, amount) {
    const n = Math.max(0, Number(amount) || 0);
    if (!n) return;
    this.db
      .prepare("UPDATE users SET coins = coins + ?, updated_at = ? WHERE user_id = ?")
      .run(n, Date.now(), String(userId));
    this._syncUsersToJson();
  }

  applyReferral({ referrerId, newUserId }) {
    const a = String(referrerId || "");
    const b = String(newUserId || "");
    if (!a || !b || a === b) return false;

    const referred = this.getUser(b);
    const referrer = this.getUser(a);
    if (!referred || !referrer) return false;
    if (clean(referred.referred_by)) return false;

    const already = this.db.prepare("SELECT referred_id FROM referrals WHERE referred_id = ?").get(b);
    if (already) return false;

    const now = Date.now();
    const trx = this.db.transaction(() => {
      this.db
        .prepare("INSERT INTO referrals (referrer_id, referred_id, created_at) VALUES (?, ?, ?)")
        .run(a, b, now);
      this.db
        .prepare(`
          UPDATE users
          SET referrals = referrals + 1,
              earned = earned + 1,
              coins = coins + 1,
              updated_at = ?
          WHERE user_id = ?
        `)
        .run(now, a);
      this.db
        .prepare("UPDATE users SET referred_by = ?, updated_at = ? WHERE user_id = ?")
        .run(a, now, b);
    });

    trx();
    this._syncUsersToJson();
    return true;
  }
}
