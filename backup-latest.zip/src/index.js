import fs from "fs";
import path from "path";
import { execFile } from "child_process";
import { promisify } from "util";
import { fileURLToPath } from "url";
import { Bot, InlineKeyboard, InputFile } from "grammy";
import config from "./config.js";
import { err, log, warn } from "./utils/logger.js";
import GithubFlowService from "./services/githubFlowService.js";
import TrackerService from "./services/trackerService.js";
import SqliteStore from "./store/sqliteStore.js";
import SqlServerStore from "./store/sqlServerStore.js";

const execFileAsync = promisify(execFile);
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "..");
const proofDir = path.resolve(projectRoot, "proof");
const genProofScriptPath = path.resolve(proofDir, "genproof.js");
const defaultGeneratedProofPath = path.resolve(proofDir, "idcard-output.png");
const photoPoolReadyDir = path.resolve(proofDir, "photo-pool", "ready");
const photoPoolManifestPath = path.resolve(proofDir, "photo-pool", "manifest.json");
const femaleNameFilePath = path.resolve(proofDir, "name-female.txt");
const maleNameFilePath = path.resolve(proofDir, "name-male.txt");

const clean = (v) => String(v || "").trim();
const isImageFilename = (name = "") => /\.(jpg|jpeg|png|webp)$/i.test(String(name || ""));

const listPhotoPoolReadyFiles = () => {
  if (!fs.existsSync(photoPoolReadyDir)) return [];
  try {
    const entries = fs.readdirSync(photoPoolReadyDir, { withFileTypes: true });
    return entries
      .filter((entry) => entry.isFile() && isImageFilename(entry.name))
      .map((entry) => path.join(photoPoolReadyDir, entry.name));
  } catch {
    return [];
  }
};

const listManifestEntries = () => {
  if (!fs.existsSync(photoPoolManifestPath)) return [];
  try {
    const raw = JSON.parse(fs.readFileSync(photoPoolManifestPath, "utf8"));
    if (!Array.isArray(raw)) return [];
    return raw
      .map((item) => ({
        file: clean(item?.file),
        gender: clean(item?.gender).toLowerCase()
      }))
      .filter((item) => item.file && ["male", "female"].includes(item.gender));
  } catch {
    return [];
  }
};

const ensureGenderNameFiles = () => {
  if (!fs.existsSync(femaleNameFilePath)) {
    throw new Error(`Gender name file missing: ${femaleNameFilePath}`);
  }
  if (!fs.existsSync(maleNameFilePath)) {
    throw new Error(`Gender name file missing: ${maleNameFilePath}`);
  }
};

const ensurePhotoPoolReady = () => {
  ensureGenderNameFiles();
  const files = listPhotoPoolReadyFiles();
  if (!files.length) {
    throw new Error(`Photo pool kosong/tidak valid: ${photoPoolReadyDir}`);
  }
  const fileSet = new Set(files.map((p) => path.basename(p)));
  const manifestEntries = listManifestEntries();
  if (!manifestEntries.length) {
    throw new Error(`Manifest photo pool kosong/tidak valid: ${photoPoolManifestPath}`);
  }
  for (const item of manifestEntries) {
    if (!fileSet.has(item.file)) {
      throw new Error(`Manifest file tidak ditemukan di ready pool: ${item.file}`);
    }
  }
  return manifestEntries.length;
};

if (!config.telegramBotToken || config.telegramBotToken === "PASTE_TELEGRAM_BOT_TOKEN") {
  throw new Error("Isi telegramBotToken dulu di src/config.js");
}

ensurePhotoPoolReady();

const bot = new Bot(config.telegramBotToken);
const github = new GithubFlowService();
const tracker = new TrackerService(github);
const DB_ENGINE = clean(config.database?.engine || "sqlite").toLowerCase();
const db =
  DB_ENGINE === "sqlserver"
    ? new SqlServerStore(config.database?.mssql, config.storage.usersJsonFile)
    : new SqliteStore(config.storage.sqliteFile, config.storage.usersJsonFile);
const activeByUser = new Set();
const waitingVerificationInputUsers = new Set();
const queuedByUser = new Set();
const verificationQueue = [];
let runningWorkers = 0;
const VERIFICATION_COST = 5;
const MIN_ACCOUNT_AGE_DAYS = Math.max(0, Number(config.verification?.minAccountAgeDays) || 0);
const VERIFICATION_WORKER_CONCURRENCY = 600;
const VERIFICATION_QUEUE_LIMIT = 50000;

const verificationLogsPath = path.resolve(clean(config.storage?.verificationLogsPath || "./data/logs.json"));
const verificationLogMaxEntries = Math.max(1000, Number(config.debug?.verificationLogMaxEntries) || 50000);

const appendVerificationLog = (entry = {}) => {
  try {
    const now = Date.now();
    const dir = path.dirname(verificationLogsPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    let parsed = { logs: [] };
    if (fs.existsSync(verificationLogsPath)) {
      try {
        const raw = fs.readFileSync(verificationLogsPath, "utf8");
        const json = JSON.parse(raw);
        if (json && Array.isArray(json.logs)) parsed.logs = json.logs;
      } catch {
        parsed = { logs: [] };
      }
    }

    const safe = {
      ts: now,
      userId: clean(entry.userId),
      tgUsername: clean(entry.tgUsername),
      email: clean(entry.email),
      status: clean(entry.status),
      stage: clean(entry.stage),
      reason: clean(entry.reason),
      metadataId: clean(entry.metadataId),
      durationSec: Math.max(0, Number(entry.durationSec) || 0)
    };
    parsed.logs.push(safe);
    if (parsed.logs.length > verificationLogMaxEntries) {
      parsed.logs = parsed.logs.slice(parsed.logs.length - verificationLogMaxEntries);
    }
    fs.writeFileSync(verificationLogsPath, JSON.stringify(parsed, null, 2));
  } catch (e) {
    warn("appendVerificationLog failed:", e?.message || e);
  }
};

const parseGhsInput = (text) => {
  const raw = clean(text);
  const m = raw.match(/^([^,]+),\s([^,]+),\s([^,]+)$/);
  if (!m) return null;
  const email = clean(m[1]);
  const password = clean(m[2]);
  const otp = clean(m[3]);
  if (!email || !password || !otp) return null;
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return null;
  return { email, password, otp };
};

const parseAddressLines = (rawText) => {
  const out = [];
  for (const rawLine of String(rawText || "").split(/\r?\n/)) {
    const line = clean(rawLine);
    const m = line.match(/^\d+\.\s*(.+)$/);
    if (!m) continue;
    const addr = clean(m[1]);
    if (addr) out.push(addr);
  }
  return out;
};

const pickRandomBillingAddress1 = () => {
  const fallback = clean(config.github?.billing?.address1);
  const filePath = clean(config.github?.billing?.addressFilePath);
  if (!filePath) return fallback;

  try {
    const raw = fs.readFileSync(path.resolve(filePath), "utf8");
    const addresses = parseAddressLines(raw);
    if (!addresses.length) return fallback;
    const idx = Math.floor(Math.random() * addresses.length);
    return clean(addresses[idx]) || fallback;
  } catch {
    return fallback;
  }
};

const parseGenProofResult = (stdout = "", stderr = "") => {
  const text = [String(stdout || ""), String(stderr || "")].filter(Boolean).join("\n");
  const lines = text
    .split(/\r?\n/)
    .map((line) => clean(line))
    .filter(Boolean);

  for (let i = lines.length - 1; i >= 0; i -= 1) {
    try {
      const parsed = JSON.parse(lines[i]);
      const outputPath = clean(parsed?.outputPath);
      const fullName = clean(parsed?.fullName);
      if (outputPath && fullName) {
        return { outputPath, fullName, raw: text };
      }
    } catch {
      // ignore non-json lines
    }
  }

  return { outputPath: "", fullName: "", raw: text };
};

const profileFromFullName = (fullNameInput) => {
  const fullName = clean(fullNameInput);
  const parts = fullName.split(/\s+/).filter(Boolean);
  if (parts.length < 2) {
    throw new Error(`Generated full name is invalid: "${fullName}"`);
  }

  return {
    firstName: parts[0],
    lastName: parts.slice(1).join(" "),
    fullName: parts.join(" ")
  };
};

const generateProofFromGenProof = async () => {
  ensurePhotoPoolReady();
  if (!fs.existsSync(genProofScriptPath)) {
    throw new Error(`genproof.js not found: ${genProofScriptPath}`);
  }

  const metaFilePath = path.join(
    proofDir,
    `.genproof-meta-${Date.now()}-${Math.random().toString(36).slice(2, 10)}.json`
  );

  let parsed = { outputPath: "", fullName: "", raw: "" };
  try {
    const { stdout, stderr } = await execFileAsync(
      "node",
      [genProofScriptPath, "--auto", "--json", "--meta-file", metaFilePath],
      {
        cwd: proofDir,
        maxBuffer: 8 * 1024 * 1024
      }
    );
    parsed = parseGenProofResult(stdout, stderr);
  } catch (error) {
    const stdout = String(error?.stdout || "");
    const stderr = String(error?.stderr || "");
    parsed = parseGenProofResult(stdout, stderr);
    if (!fs.existsSync(metaFilePath) && !parsed.outputPath) {
      throw error;
    }
  }

  if (fs.existsSync(metaFilePath)) {
    try {
      const rawMeta = fs.readFileSync(metaFilePath, "utf8");
      const meta = JSON.parse(rawMeta);
      parsed = {
        outputPath: clean(meta?.outputPath),
        fullName: clean(meta?.fullName),
        raw: rawMeta
      };
    } finally {
      fs.unlinkSync(metaFilePath);
    }
  }

  if (!parsed.outputPath) {
    throw new Error(`Failed to parse output path from genproof.js. Output: ${parsed.raw || "empty"}`);
  }
  if (!parsed.fullName) {
    throw new Error(`Failed to parse generated name from genproof.js. Output: ${parsed.raw || "empty"}`);
  }

  const proofPath = path.isAbsolute(parsed.outputPath)
    ? parsed.outputPath
    : path.resolve(proofDir, parsed.outputPath);

  if (!fs.existsSync(proofPath)) {
    throw new Error(`Generated proof file not found: ${proofPath}`);
  }

  return {
    proofPath,
    fullName: parsed.fullName
  };
};


const toDisplayName = (from = {}) =>
  clean([from.first_name, from.last_name].filter(Boolean).join(" ")) || "user";
const isOwner = (userId) =>
  (config.ownerTelegramIds || []).map((x) => String(x)).includes(String(userId));

const getMenuKeyboard = (supportUsername = config.supportUsername) => {
  const kb = new InlineKeyboard()
    .text("START VERIFICATION", "start_verification")
    .row()
    .text("REFERRALS", "referrals")
    .row();
  if (supportUsername) {
    kb.url("CONTACT SUPPORT", `https://t.me/${supportUsername.replace(/^@/, "")}`);
  } else {
    kb.text("CONTACT SUPPORT", "contact_support");
  }
  return kb;
};

const getBackKeyboard = () => new InlineKeyboard().text("BACK TO MENU", "back_menu");
const getCancelVerificationKeyboard = () =>
  new InlineKeyboard().text("❌ CANCEL", "cancel_verification");
const getRetryVerificationKeyboard = () =>
  new InlineKeyboard().text("VERIFY AGAIN", "start_verification").row().text("BACK TO HOME", "back_menu");

const requiredJoinConfig = config.accessGate?.requiredJoin || {};

const isJoinGateEnabled = () =>
  Boolean(requiredJoinConfig.enabled && clean(requiredJoinConfig.chatId) && clean(requiredJoinConfig.url));

const checkUserJoinedRequiredGroup = async (ctx) => {
  if (!isJoinGateEnabled()) return true;
  const userId = Number(ctx.from?.id || 0);
  if (!userId) return false;

  try {
    const member = await bot.api.getChatMember(clean(requiredJoinConfig.chatId), userId);
    const status = clean(member?.status).toLowerCase();
    return ["creator", "administrator", "member"].includes(status);
  } catch {
    return false;
  }
};

const ensureJoinGate = async (ctx) => {
  if (!isJoinGateEnabled()) return true;
  const joined = await checkUserJoinedRequiredGroup(ctx);
  if (joined) return true;

  const kb = new InlineKeyboard()
    .url("JOIN GROUP", clean(requiredJoinConfig.url))
    .row()
    .text("CONFIRM", "confirm_join_gate");

  await ctx.reply(
    [
      "You must join the discussion group before using this bot.",
      `• Group: ${clean(requiredJoinConfig.chatId)}`
    ].join("\n"),
    { parse_mode: "HTML", reply_markup: kb }
  );
  return false;
};

const parseFailureDetail = (errorInput) => {
  const raw = clean(errorInput) || "Unknown error";
  let stage = "verification";
  let details = "Unexpected verification error.";
  let hint = "please try again with fresh credentials and otp.";

  if (/OTP verification failed|incorrect one-time password|incorrect code/i.test(raw)) {
    stage = "2FA";
    details = "your otp is invalid or expired. use a fresh otp and retry immediately.";
    hint = "your otp is invalid or expired. use a fresh otp and retry immediately.";
  } else if (/GitHub device verification required|sessions\/verified-device|device verification code/i.test(raw)) {
    stage = "device verification";
    details = "bot cannot continue because github requested device verification (email code challenge).";
    hint = "open github in browser, complete device verification, then retry from bot. challenge can reappear anytime.";
  } else if (/Login failed|Login form not found/i.test(raw)) {
    stage = "login";
    details = "github login failed. check your email/password and try again.";
    hint = "github login failed. check your email/password and try again.";
  } else if (/Profile name update failed|Profile update form not found/i.test(raw)) {
    stage = "profile update";
    details = "failed to sync github profile name.";
    hint = "failed to sync github profile name.";
  } else if (/Billing form not found|payment_information|billing/i.test(raw)) {
    stage = "billing update";
    details = "failed to sync billing information.";
    hint = "failed to sync billing information.";
  } else if (/photo_proof upload form did not appear|Application form not found/i.test(raw)) {
    stage = "application submit";
    details = "failed to open or continue the education application form.";
    hint = "failed to open or continue the education application form.";
  } else if (
    /genproof\.js not found|Failed to parse output path from genproof|Failed to parse generated name from genproof|Generated proof file not found|Generated full name is invalid|Generated profile or billing address is invalid/i.test(
      raw
    )
  ) {
    stage = "proof generation";
    details = "failed to generate proof image automatically.";
    hint = "failed to generate proof image automatically.";
  } else if (/Photo pool kosong\/tidak valid/i.test(raw)) {
    stage = "proof generation";
    details = "photo pool is empty or invalid. upload images to proof/photo-pool/ready first.";
    hint = "photo pool is empty or invalid. upload images to proof/photo-pool/ready first.";
  } else if (/Manifest photo pool kosong\/tidak valid|Manifest file tidak ditemukan di ready pool/i.test(raw)) {
    stage = "proof generation";
    details = "photo manifest is missing/invalid or not aligned with ready pool files.";
    hint = "photo manifest is missing/invalid or not aligned with ready pool files.";
  } else if (/Gender name file missing|File nama gender tidak ketemu/i.test(raw)) {
    stage = "proof generation";
    details = "gender name files are missing. prepare name-male.txt and name-female.txt.";
    hint = "gender name files are missing. prepare name-male.txt and name-female.txt.";
  } else if (/Configured profile or billing address is invalid/i.test(raw)) {
    stage = "profile sync";
    details = "configured profile or billing data is invalid.";
    hint = "configured profile or billing data is invalid.";
  } else if (/Default ID card not found/i.test(raw)) {
    stage = "document upload";
    details = "default id card file is missing on server.";
    hint = "default id card file is missing on server.";
  } else if (/Failed to read GitHub username|Failed to read GitHub account age/i.test(raw)) {
    stage = "account age check";
    details = "failed to verify github account age. please retry.";
    hint = "failed to verify github account age. please retry.";
  }

  return {
    stage,
    details,
    hint,
    raw
  };
};

const renderDashboardText = ({ from, user }) => {
  return [
    "<b>GITHUB STUDENT VERIFICATION BOT</b>",
    "",
    "<b>Dashboard</b>",
    `• Name: ${toDisplayName(from)}`,
    `• ID: ${from.id}`,
    `• Coins: ${Number(user.coins)}`,
    "",
    "<b>Verification rules</b>",
    "• 2FA must be enabled (authenticator app)",
    "• Account age must be at least 3 days",
    "",
    "<b>Coins policy</b>",
    `• Cost per verification: ${VERIFICATION_COST} coins`,
    "• Approved: coin deducted",
    "• Rejected: free (coin returned)"
  ].join("\n");
};

const renderReferralsText = ({ botUsername, user }) => {
  const refLink = botUsername
    ? `https://t.me/${botUsername}?start=ref_${user.user_id}`
    : `ref_${user.user_id}`;
  return [
    "<b>Invite friends & get coins!</b>",
    "",
    "<b>Your stats:</b>",
    `• Referrals: ${Number(user.referrals)}`,
    `• Earned: ${Number(user.earned)}`,
    "• +1 coins per referral",
    "",
    "<b>Your referral link:</b>",
    `• ${refLink}`,
    "",
    "Share this link to get coins!"
  ].join("\n");
};

const sendMenu = async (ctx, botUsername = "") => {
  const u = await db.ensureUser(ctx.from);
  const imagePath = path.resolve(config.storage.menuImagePath);
  const caption = renderDashboardText({ from: ctx.from, user: u, botUsername });
  if (fs.existsSync(imagePath)) {
    await ctx.replyWithPhoto(new InputFile(imagePath), {
      caption,
      parse_mode: "HTML",
      reply_markup: getMenuKeyboard(),
      disable_notification: true
    });
  } else {
    await ctx.reply(caption, { parse_mode: "HTML", reply_markup: getMenuKeyboard() });
  }
};

const tryApplyReferralFromStartPayload = async (ctx) => {
  const payload = clean(ctx.match);
  if (!payload || !payload.startsWith("ref_")) return false;
  const referrerId = clean(payload.slice(4));
  if (!/^\d+$/.test(referrerId)) return false;
  await db.ensureUser(ctx.from);
  return db.applyReferral({
    referrerId,
    newUserId: String(ctx.from.id)
  });
};

bot.command("start", async (ctx) => {
  await db.ensureUser(ctx.from);
  await tryApplyReferralFromStartPayload(ctx);
  if (!(await ensureJoinGate(ctx))) return;
  const me = await bot.api.getMe().catch(() => null);
  await sendMenu(ctx, clean(me?.username));
});

bot.command("menu", async (ctx) => {
  await db.ensureUser(ctx.from);
  if (!(await ensureJoinGate(ctx))) return;
  const me = await bot.api.getMe().catch(() => null);
  await sendMenu(ctx, clean(me?.username));
});

bot.command("ghs", async (ctx) => {
  if (!(await ensureJoinGate(ctx))) return;
  waitingVerificationInputUsers.delete(String(ctx.from?.id || ""));
  const inputText = ctx.match;
  return enqueueVerificationJob(ctx, inputText);
});

const runGhsVerification = async (ctx, inputText) => {
  const userId = String(ctx.from?.id || "");
  const tgUsername = clean(ctx.from?.username || "");
  if (!userId) return;
  await db.ensureUser(ctx.from);

  if (activeByUser.has(userId)) {
    await ctx.reply("An active job is still running. please wait until it finishes.");
    return;
  }

  const user = await db.getUser(userId);
  if (Number(user.coins) < VERIFICATION_COST) {
    await ctx.reply(`Insufficient coins. you need ${VERIFICATION_COST} coins to start verification.`, {
      reply_markup: getBackKeyboard()
    });
    return;
  }

  const parsed = parseGhsInput(inputText);
  if (!parsed) {
    await ctx.reply("Format: email, password, otp", {
      reply_markup: getBackKeyboard()
    });
    return;
  }
  const startedAt = Date.now();
  activeByUser.add(userId);
  await db.incrementVerifications(userId);
  let generatedProofPath = "";

  try {
    await ctx.reply(
      [
        "<b>GITHUB STUDENT VERIFICATION</b>",
        "",
        `• Email: ${parsed.email}`,
        "• Stage: signing in",
        "• Details: authenticating with github..."
      ].join("\n"),
      { parse_mode: "HTML" }
    );

    const session = github.createSession();
    await github.loginWith2fa(session, {
      email: parsed.email,
      password: parsed.password,
      otp: parsed.otp
    });

    await ctx.reply(
      [
        "<b>GITHUB STUDENT VERIFICATION</b>",
        "",
        `• Email: ${parsed.email}`,
        "• Stage: eligibility check",
        `• Details: validating account age...`
      ].join("\n"),
      { parse_mode: "HTML" }
    );

    const ageCheck = await github.checkAccountAgeAtLeastDays(session, MIN_ACCOUNT_AGE_DAYS);
    if (!ageCheck.ok) {
      await db.incrementFailed(userId);
      const u2 = await db.getUser(userId);
      const waitDays = Math.max(1, MIN_ACCOUNT_AGE_DAYS - Math.max(0, Number(ageCheck.ageDays) || 0));
      appendVerificationLog({
        userId,
        tgUsername,
        email: parsed.email,
        status: "rejected",
        stage: "eligibility check",
        reason: `account age ${Number(ageCheck.ageDays) || 0}d < ${MIN_ACCOUNT_AGE_DAYS}d`,
        durationSec: Math.max(1, Math.round((Date.now() - startedAt) / 1000))
      });
      await ctx.reply(
        [
          "❌ <b>APPLICATION REJECTED!</b>",
          "",
          "Your github student developer pack has been rejected!",
          "",
          `• Rejected in: ${Math.max(1, Math.round((Date.now() - startedAt) / 1000))}s`,
          "• Coins charged: no",
          `• Remaining coins: ${u2.coins}`,
          "",
          `⚠️ Your github account was too recently created. please apply again in ${waitDays} day${waitDays > 1 ? "s" : ""}.`
        ].join("\n"),
        { parse_mode: "HTML" }
      );
      return;
    }

    await ctx.reply(
      [
        "<b>GITHUB STUDENT VERIFICATION</b>",
        "",
        `• Email: ${parsed.email}`,
        "• Stage: proof generation",
        "• Details: generating proof automatically..."
      ].join("\n"),
      { parse_mode: "HTML" }
    );

    const proofGenerated = await generateProofFromGenProof();
    generatedProofPath = proofGenerated.proofPath;
    const profile = profileFromFullName(proofGenerated.fullName);
    const billingAddress1 = pickRandomBillingAddress1();
    if (!profile.fullName || !profile.firstName || !profile.lastName || !billingAddress1) {
      throw new Error("Generated profile or billing address is invalid.");
    }

    await github.updateProfileName(session, profile.fullName);
    await github.updateBilling(session, {
      firstName: profile.firstName,
      lastName: profile.lastName,
      address1: billingAddress1
    });

    await ctx.reply(
      [
        "<b>GITHUB STUDENT VERIFICATION</b>",
        "",
        `• Email: ${parsed.email}`,
        "• Stage: profile sync",
        `• Details: profile + billing synced`
      ].join("\n"),
      { parse_mode: "HTML" }
    );

    const idCardBuffer = fs.readFileSync(proofGenerated.proofPath);

    await github.submitPhotoProof(session, {
      email: parsed.email,
      idCardBuffer,
      idCardPath: proofGenerated.proofPath
    });
    try {
      fs.unlinkSync(proofGenerated.proofPath);
      generatedProofPath = "";
    } catch {
      // Ignore cleanup failure.
    }

    const metadataId = await github.findLatestMetadataId(session);
    await ctx.reply(
      [
        "<b>GITHUB STUDENT VERIFICATION</b>",
        "",
        `• Email: ${parsed.email}`,
        "• Stage: submitted",
        "• Details: pending review results. takes 5 minutes"
      ].join("\n"),
      { parse_mode: "HTML" }
    );

    if (!metadataId) {
      await db.incrementFailed(userId);
      appendVerificationLog({
        userId,
        tgUsername,
        email: parsed.email,
        status: "failed",
        stage: "tracking",
        reason: "metadata ID not found",
        durationSec: Math.max(1, Math.round((Date.now() - startedAt) / 1000))
      });
      await ctx.reply("Tracking failed: metadata ID not found.");
      return;
    }

    const finalState = await tracker.trackUntilFinal(session, metadataId, async () => {});

    if (finalState === "approved") {
      await db.incrementSuccess(userId);
      await db.deductCoins(userId, VERIFICATION_COST);
      const u2 = await db.getUser(userId);
      appendVerificationLog({
        userId,
        tgUsername,
        email: parsed.email,
        status: "approved",
        stage: "completed",
        metadataId,
        durationSec: Math.max(1, Math.round((Date.now() - startedAt) / 1000))
      });
      await ctx.reply(
        [
          "✅ <b>APPLICATION APPROVED!</b>",
          "",
          "Your github student developer pack has been approved!",
          "",
          `• Application ID: ${metadataId}`,
          `• Verified in: ${Math.max(1, Math.round((Date.now() - startedAt) / 1000))}s`,
          `• Coins charged: ${VERIFICATION_COST}`,
          `• Remaining coins: ${u2.coins}`,
          "",
          "🌟 <b>Congratulations! your benefits will become available within 72 hours.</b>"
        ].join("\n"),
        { parse_mode: "HTML" }
      );
    } else if (finalState === "rejected") {
      await db.incrementFailed(userId);
      const u2 = await db.getUser(userId);
      const latest = await github.fetchMetadataStatus(session, metadataId).catch(() => null);
      const reason = clean(github.extractRejectedReason(latest?.html || "")) || "Unknown reject reason.";
      const genericReason = /unknown reject reason|visit our edu community|faq(?:s)? and tips/i.test(reason);
      const fallbackHint =
        "Unable to verify student proof. check photo clarity, profile identity match, school email/domain, and account age before retry.";
      const displayReason = genericReason ? fallbackHint : reason;
      appendVerificationLog({
        userId,
        tgUsername,
        email: parsed.email,
        status: "rejected",
        stage: "review",
        metadataId,
        reason: displayReason,
        durationSec: Math.max(1, Math.round((Date.now() - startedAt) / 1000))
      });
      await ctx.reply(
        [
          "❌ <b>APPLICATION REJECTED!</b>",
          "",
          "Your github student developer pack has been rejected!",
          "",
          `• Application ID: ${metadataId}`,
          `• Rejected in: ${Math.max(1, Math.round((Date.now() - startedAt) / 1000))}s`,
          "• Coins charged: no",
          `• Remaining coins: ${u2.coins}`,
          "",
          `⚠️ ${displayReason}`
        ].join("\n"),
        { parse_mode: "HTML" }
      );

    } else {
      appendVerificationLog({
        userId,
        tgUsername,
        email: parsed.email,
        status: "pending",
        stage: "tracking",
        metadataId,
        reason: "still pending/review",
        durationSec: Math.max(1, Math.round((Date.now() - startedAt) / 1000))
      });
      await ctx.reply("⏳ The application is still pending/review. tracking will continue.");
    }
  } catch (e) {
    await db.incrementFailed(userId);
    const rawError = clean(e?.response?.data?.message || e?.message || e);
    const failure = parseFailureDetail(rawError);
    appendVerificationLog({
      userId,
      tgUsername,
      email: parsed?.email,
      status: "failed",
      stage: failure.stage,
      reason: failure.details,
      durationSec: Math.max(1, Math.round((Date.now() - startedAt) / 1000))
    });
    warn("ghs error:", rawError);
    await ctx.reply(
      [
        "❌ <b>VERIFICATION FAILED</b>",
        "",
        `• Email: ${clean(parsed?.email || "-")}`,
        `• Stage: ${failure.stage}`,
        `• Details: ${failure.details}`
      ].join("\n"),
      { parse_mode: "HTML", reply_markup: getRetryVerificationKeyboard() }
    );
  } finally {
    const cleanupCandidates = [generatedProofPath, defaultGeneratedProofPath]
      .map((p) => clean(p))
      .filter(Boolean);

    for (const filePath of new Set(cleanupCandidates)) {
      try {
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
      } catch {
        // Ignore cleanup failure.
      }
    }
    activeByUser.delete(userId);
  }
};

const pumpVerificationQueue = () => {
  if (runningWorkers >= VERIFICATION_WORKER_CONCURRENCY) return;
  while (runningWorkers < VERIFICATION_WORKER_CONCURRENCY && verificationQueue.length > 0) {
    const next = verificationQueue.shift();
    if (!next) break;
    runningWorkers += 1;
    Promise.resolve()
      .then(() => runGhsVerification(next.ctx, next.inputText))
      .catch((e) => warn("queue worker error:", e?.message || e))
      .finally(() => {
        runningWorkers = Math.max(0, runningWorkers - 1);
        queuedByUser.delete(next.userId);
        pumpVerificationQueue();
      });
  }
};

const enqueueVerificationJob = async (ctx, inputText) => {
  const userId = String(ctx.from?.id || "");
  if (!userId) return;

  if (activeByUser.has(userId) || queuedByUser.has(userId)) {
    await ctx.reply("You already have an active/queued verification job. please wait until it finishes.");
    return;
  }

  if (verificationQueue.length >= VERIFICATION_QUEUE_LIMIT) {
    await ctx.reply("Verification queue is full right now. please retry in a few minutes.");
    return;
  }

  queuedByUser.add(userId);
  verificationQueue.push({
    userId,
    inputText,
    ctx
  });
  pumpVerificationQueue();
};

bot.callbackQuery("start_verification", async (ctx) => {
  await db.ensureUser(ctx.from);
  if (!(await ensureJoinGate(ctx))) {
    await ctx.answerCallbackQuery();
    return;
  }
  waitingVerificationInputUsers.add(String(ctx.from?.id || ""));
  await ctx.answerCallbackQuery();
  await ctx.reply(
    [
      "⏳ <b>START VERIFICATION</b>",
      "",
      "Send your github email, password, otp",
      "",
      "Ex:",
      "• myemail@gmail.com, mypass, 123456"
    ].join("\n"),
    { parse_mode: "HTML", reply_markup: getCancelVerificationKeyboard() }
  );
});

bot.callbackQuery("cancel_verification", async (ctx) => {
  waitingVerificationInputUsers.delete(String(ctx.from?.id || ""));
  await ctx.answerCallbackQuery();
  await ctx.reply("Verification input canceled.", {
    reply_markup: getBackKeyboard()
  });
});

bot.on("message:text", async (ctx) => {
  const userId = String(ctx.from?.id || "");
  if (!userId) return;
  if (!(await ensureJoinGate(ctx))) return;
  if (!waitingVerificationInputUsers.has(userId)) return;
  const text = clean(ctx.message?.text);
  if (!text || text.startsWith("/")) return;
  waitingVerificationInputUsers.delete(userId);
  await enqueueVerificationJob(ctx, text);
});

bot.callbackQuery("referrals", async (ctx) => {
  await db.ensureUser(ctx.from);
  await ctx.answerCallbackQuery();
  const me = await bot.api.getMe().catch(() => null);
  const user = await db.getUser(String(ctx.from.id));
  await ctx.reply(renderReferralsText({ botUsername: clean(me?.username), user }), {
    parse_mode: "HTML",
    reply_markup: getBackKeyboard()
  });
});

bot.callbackQuery("back_menu", async (ctx) => {
  await ctx.answerCallbackQuery();
  if (!(await ensureJoinGate(ctx))) return;
  const me = await bot.api.getMe().catch(() => null);
  await sendMenu(ctx, clean(me?.username));
});

bot.callbackQuery("contact_support", async (ctx) => {
  await ctx.answerCallbackQuery();
  await ctx.reply(`Contact support: @${clean(config.supportUsername || "support")}`, {
    reply_markup: getBackKeyboard()
  });
});

bot.callbackQuery("confirm_join_gate", async (ctx) => {
  await db.ensureUser(ctx.from);
  const joined = await checkUserJoinedRequiredGroup(ctx);
  if (!joined) {
    await ctx.answerCallbackQuery({ text: "You are not in the group yet.", show_alert: true });
    if (isJoinGateEnabled()) {
      await ctx.reply(
        "Please join the group first, then press CONFIRM again.",
        {
          reply_markup: new InlineKeyboard()
            .url("JOIN GROUP", clean(requiredJoinConfig.url))
            .row()
            .text("CONFIRM", "confirm_join_gate")
        }
      );
    }
    return;
  }

  await ctx.answerCallbackQuery({ text: "Confirmed." });
  const me = await bot.api.getMe().catch(() => null);
  await sendMenu(ctx, clean(me?.username));
});

bot.catch((e) => {
  err("bot.catch:", e.error?.message || e.error || e);
});

bot
  .start()
  .then(() => log("Telegram bot running"))
  .catch((e) => err("start failed:", e.message || e));
