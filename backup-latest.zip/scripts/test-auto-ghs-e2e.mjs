import assert from "assert";
import fs from "fs";
import os from "os";
import path from "path";
import { fileURLToPath } from "url";
import SqliteStore from "../src/store/sqliteStore.js";
import GithubFlowService from "../src/services/githubFlowService.js";
import TrackerService from "../src/services/trackerService.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "..");
const proofDir = path.resolve(projectRoot, "proof");

const clean = (v) => String(v || "").trim();

const ensure = (cond, message) => {
  if (!cond) throw new Error(message);
};

const parseGhsInput = (text) => {
  const trimmed = clean(text);
  let body = trimmed;
  if (/^\/ghs\b/i.test(body)) body = body.replace(/^\/ghs\b/i, "").trim();
  const parts = body.split(",").map((x) => clean(x));
  if (parts.length !== 3 || parts.some((p) => !p)) throw new Error("Invalid /ghs format");
  return { email: parts[0], password: parts[1], otp: parts[2] };
};

const listReadyPhotos = () => {
  const dir = path.join(proofDir, "photo-pool", "ready");
  if (!fs.existsSync(dir)) return [];
  return fs
    .readdirSync(dir)
    .filter((n) => /\.(jpg|jpeg|png|webp)$/i.test(n))
    .map((n) => path.join(dir, n));
};

const readManifest = () => {
  const p = path.join(proofDir, "photo-pool", "manifest.json");
  if (!fs.existsSync(p)) return [];
  const raw = JSON.parse(fs.readFileSync(p, "utf8"));
  if (!Array.isArray(raw)) return [];
  return raw
    .map((x) => ({ file: clean(x?.file), gender: clean(x?.gender).toLowerCase() }))
    .filter((x) => x.file && ["male", "female"].includes(x.gender));
};

const checkProofPrerequisites = () => {
  const ready = listReadyPhotos();
  ensure(ready.length > 0, "photo-pool/ready kosong");

  const manifest = readManifest();
  ensure(manifest.length > 0, "manifest.json kosong/invalid");

  const readySet = new Set(ready.map((p) => path.basename(p)));
  for (const item of manifest) ensure(readySet.has(item.file), `manifest file missing in ready: ${item.file}`);

  const male = path.join(proofDir, "name-male.txt");
  const female = path.join(proofDir, "name-female.txt");
  ensure(fs.existsSync(male) && clean(fs.readFileSync(male, "utf8")), "name-male.txt missing/empty");
  ensure(fs.existsSync(female) && clean(fs.readFileSync(female, "utf8")), "name-female.txt missing/empty");
};

const fakeGenerateProof = (() => {
  let seq = 0;
  return () => {
    const manifest = readManifest();
    const chosen = manifest[seq % manifest.length];
    seq += 1;
    const sourcePhotoPath = path.join(proofDir, "photo-pool", "ready", chosen.file);
    const sourceNameFile = path.join(proofDir, chosen.gender === "male" ? "name-male.txt" : "name-female.txt");
    const proofPath = path.join(os.tmpdir(), `ghs-e2e-proof-${Date.now()}-${seq}.png`);
    fs.copyFileSync(sourcePhotoPath, proofPath);
    return {
      proofPath,
      orderNumber: String(seq),
      fullName: chosen.gender === "male" ? "Bima Pratama" : "Alya Putri",
      sourcePhotoPath,
      sourcePhotoMode: "pool_manifest",
      sourceGender: chosen.gender,
      sourceNameFile
    };
  };
})();

class FakeGithubService {
  constructor({ ageDays, finalState }) {
    this.ageDays = ageDays;
    this.finalState = finalState;
    this.calls = [];
    this.rejectedHtml = "";
  }

  createSession() {
    this.calls.push("createSession");
    return { fake: true };
  }

  async loginWith2fa(_session, _parsed) {
    this.calls.push("loginWith2fa");
  }

  async checkAccountAgeAtLeastDays(_session, minDays) {
    this.calls.push("checkAccountAgeAtLeastDays");
    return {
      ok: this.ageDays >= minDays,
      username: "fakeuser",
      ageDays: this.ageDays,
      joinedAt: new Date(Date.now() - this.ageDays * 24 * 60 * 60 * 1000)
    };
  }

  async updateProfileName(_session, _fullName) {
    this.calls.push("updateProfileName");
  }

  async updateBilling(_session, _payload) {
    this.calls.push("updateBilling");
  }

  async submitPhotoProof(_session, payload) {
    this.calls.push("submitPhotoProof");
    ensure(Buffer.isBuffer(payload.idCardBuffer), "idCardBuffer must be Buffer");
  }

  async findLatestMetadataId() {
    this.calls.push("findLatestMetadataId");
    return "999999";
  }

  async fetchMetadataStatus() {
    this.calls.push("fetchMetadataStatus");
    return { state: this.finalState, html: this.rejectedHtml };
  }

  extractRejectedReason() {
    return "Rejected by test stub";
  }
}

class FakeCtx {
  constructor(userId) {
    this.from = { id: userId, first_name: "Test", username: `u${userId}` };
    this.replies = [];
  }

  async reply(text, extra = {}) {
    this.replies.push({ text: String(text || ""), extra });
  }
}

const runFlow = async ({ ageDays, finalState }) => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "ghs-auto-e2e-"));
  const dbPath = path.join(tmp, "ghs.sqlite");
  const usersJsonPath = path.join(tmp, "users.json");
  const db = new SqliteStore(dbPath, usersJsonPath);
  const ctx = new FakeCtx("e2e-user");
  const github = new FakeGithubService({ ageDays, finalState });
  const tracker = new TrackerService(github);
  const VERIFICATION_COST = 5;
  const MIN_ACCOUNT_AGE_DAYS = 3;

  db.ensureUser(ctx.from);
  db.addCoins(String(ctx.from.id), 20);

  const parsed = parseGhsInput("/ghs user@mail.com,pw,123456");
  const startedAt = Date.now();
  let generatedProofPath = "";
  const defaultGeneratedProofPath = path.resolve(proofDir, "idcard-output.png");

  const snapshot = () => {
    const u = db.getUser("e2e-user");
    return u
      ? {
          success: Number(u.success) || 0,
          failed: Number(u.failed) || 0,
          coins: Number(u.coins) || 0
        }
      : { success: 0, failed: 0, coins: 0 };
  };

  try {
    await ctx.reply("• Stage: signing in");
    const session = github.createSession();
    await github.loginWith2fa(session, parsed);

    await ctx.reply("• Stage: eligibility check");
    const ageCheck = await github.checkAccountAgeAtLeastDays(session, MIN_ACCOUNT_AGE_DAYS);
    if (!ageCheck.ok) {
      db.incrementFailed(String(ctx.from.id));
      await ctx.reply("APPLICATION REJECTED age");
      return { ctx, github, ended: "age_reject", user: snapshot() };
    }

    await ctx.reply("• Stage: proof generation");
    const proofGenerated = fakeGenerateProof();
    generatedProofPath = proofGenerated.proofPath;

    await github.updateProfileName(session, proofGenerated.fullName);
    await github.updateBilling(session, { firstName: "A", lastName: "B", address1: "Jl Test" });
    await ctx.reply("• Stage: profile sync");

    const idCardBuffer = fs.readFileSync(proofGenerated.proofPath);
    await github.submitPhotoProof(session, {
      email: parsed.email,
      idCardBuffer,
      idCardPath: proofGenerated.proofPath
    });
    if (fs.existsSync(proofGenerated.proofPath)) fs.unlinkSync(proofGenerated.proofPath);
    generatedProofPath = "";

    const metadataId = await github.findLatestMetadataId(session);
    await ctx.reply("• Stage: submitted");

    const final = await tracker.trackUntilFinal(session, metadataId, async () => {});
    if (final === "approved") {
      db.incrementSuccess(String(ctx.from.id));
      db.deductCoins(String(ctx.from.id), VERIFICATION_COST);
      await ctx.reply("APPLICATION APPROVED");
      return { ctx, github, ended: "approved", user: snapshot() };
    }
    if (final === "rejected") {
      db.incrementFailed(String(ctx.from.id));
      await ctx.reply("APPLICATION REJECTED review");
      return { ctx, github, ended: "rejected", user: snapshot() };
    }

    await ctx.reply("pending");
    return { ctx, github, ended: "pending", user: snapshot() };
  } finally {
    for (const p of [generatedProofPath, defaultGeneratedProofPath]) {
      const f = clean(p);
      if (!f) continue;
      try {
        if (fs.existsSync(f)) fs.unlinkSync(f);
      } catch {
        // ignore
      }
    }
    db.db.close();
  }
};

const assertApprovedFlow = async () => {
  const out = await runFlow({ ageDays: 7, finalState: "approved" });
  assert.equal(out.ended, "approved");
  assert.equal(Number(out.user.success), 1);
  assert.equal(Number(out.user.failed), 0);
  assert.equal(Number(out.user.coins), 20);
  const joinedCalls = out.github.calls.join(" -> ");
  ensure(joinedCalls.includes("checkAccountAgeAtLeastDays -> updateProfileName"), "approved flow order broken");
  ensure(joinedCalls.includes("submitPhotoProof -> findLatestMetadataId"), "submit/find metadata order broken");
};

const assertAgeRejectFlow = async () => {
  const out = await runFlow({ ageDays: 1, finalState: "approved" });
  assert.equal(out.ended, "age_reject");
  assert.equal(Number(out.user.success), 0);
  assert.equal(Number(out.user.failed), 1);
  assert.equal(Number(out.user.coins), 25);
  ensure(!out.github.calls.includes("updateProfileName"), "age reject must not continue to profile sync");
  ensure(!out.github.calls.includes("submitPhotoProof"), "age reject must not submit proof");
};

const assertReviewRejectFlow = async () => {
  const out = await runFlow({ ageDays: 10, finalState: "rejected" });
  assert.equal(out.ended, "rejected");
  assert.equal(Number(out.user.success), 0);
  assert.equal(Number(out.user.failed), 1);
  assert.equal(Number(out.user.coins), 25);
};

const main = async () => {
  checkProofPrerequisites();
  await assertApprovedFlow();
  await assertAgeRejectFlow();
  await assertReviewRejectFlow();
  console.log("PASS: auto-ghs e2e scenarios passed (approved + age reject + review reject)");
};

await main();
