import sql from "mssql";
import config from "../src/config.js";

const clean = (v) => String(v || "").trim();

const cfg = config.database?.mssql || {};
if (!cfg.server || !cfg.database || !cfg.user || !cfg.password) {
  throw new Error("SQL Server config incomplete. Check src/config.js -> database.mssql");
}

const pool = new sql.ConnectionPool({
  server: clean(cfg.server),
  port: Number(cfg.port) || 1433,
  database: clean(cfg.database),
  user: clean(cfg.user),
  password: String(cfg.password || ""),
  options: {
    encrypt: cfg.options?.encrypt !== false,
    trustServerCertificate: Boolean(cfg.options?.trustServerCertificate)
  }
});

const run = async () => {
  await pool.connect();

  const users = (
    await pool
      .request()
      .query(
        "SELECT user_id, tg_name, tg_username, coins, verifications, success, failed, referrals, earned, referred_by, created_at, updated_at FROM users ORDER BY user_id ASC"
      )
  ).recordset;

  const referrals = (
    await pool
      .request()
      .query("SELECT id, referrer_id, referred_id, created_at FROM referrals ORDER BY id ASC")
  ).recordset;

  const totals = users.reduce(
    (acc, u) => {
      acc.coins += Number(u.coins) || 0;
      acc.verifications += Number(u.verifications) || 0;
      acc.success += Number(u.success) || 0;
      acc.failed += Number(u.failed) || 0;
      acc.referrals += Number(u.referrals) || 0;
      acc.earned += Number(u.earned) || 0;
      return acc;
    },
    { coins: 0, verifications: 0, success: 0, failed: 0, referrals: 0, earned: 0 }
  );

  console.log(
    JSON.stringify(
      {
        usersCount: users.length,
        referralsCount: referrals.length,
        totals,
        users,
        referrals
      },
      null,
      2
    )
  );

  await pool.close();
};

await run();
