import fs from "fs";
import os from "os";
import path from "path";
import assert from "assert";
import config from "../src/config.js";
import SqliteStore from "../src/store/sqliteStore.js";

const COST = 5;
const ownerId = "9000000001";
const userId = "9000000002";

const originalOwnerIds = Array.isArray(config.ownerTelegramIds) ? [...config.ownerTelegramIds] : [];
config.ownerTelegramIds = [ownerId];

const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "ghs-coins-test-"));
const dbPath = path.join(tmpDir, "ghs.sqlite");
const usersJsonPath = path.join(tmpDir, "users.json");

const store = new SqliteStore(dbPath, usersJsonPath);

const ensure = (id, name) => store.ensureUser({ id, first_name: name, username: name.toLowerCase() });

try {
  // 1) Default coins
  let user = ensure(userId, "User");
  let owner = ensure(ownerId, "Owner");
  assert.equal(Number(user.coins), 5, "Default user coins must be 5");
  assert.equal(Number(owner.coins), 5000, "Default owner coins must be 5000");

  // 2) User insufficient coins must be rejected
  assert.equal(Number(user.coins) < COST, false, "User default coins should cover cost 5");
  assert.equal(store.deductCoins(userId, COST), true, "Deduct must succeed at default cost 5");
  user = store.getUser(userId);
  assert.equal(Number(user.coins), 0, "User coins must become 0 after default deduct");

  // 3) User approved path: deduct 5
  store.addCoins(userId, 10); // user: 10
  store.incrementVerifications(userId);
  store.incrementSuccess(userId);
  assert.equal(store.deductCoins(userId, COST), true, "User approved deduct must succeed");
  user = store.getUser(userId);
  assert.equal(Number(user.coins), 5, "User remaining coins after approved must be 5");

  // 4) User rejected path: no deduction (coin returned/free)
  const userBeforeRejected = Number(user.coins);
  store.incrementVerifications(userId);
  store.incrementFailed(userId);
  user = store.getUser(userId);
  assert.equal(Number(user.coins), userBeforeRejected, "User coins must remain same on rejected");

  // 5) Owner approved path: deduct 5
  store.incrementVerifications(ownerId);
  store.incrementSuccess(ownerId);
  assert.equal(store.deductCoins(ownerId, COST), true, "Owner approved deduct must succeed");
  owner = store.getUser(ownerId);
  assert.equal(Number(owner.coins), 4995, "Owner remaining coins after approved must be 4995");

  // 6) Owner rejected path: no deduction (coin returned/free)
  const ownerBeforeRejected = Number(owner.coins);
  store.incrementVerifications(ownerId);
  store.incrementFailed(ownerId);
  owner = store.getUser(ownerId);
  assert.equal(Number(owner.coins), ownerBeforeRejected, "Owner coins must remain same on rejected");

  // 7) Owner normalization to exact 5000 (not huge)
  store.addCoins(ownerId, 1234); // owner becomes > 5000
  owner = ensure(ownerId, "Owner");
  assert.equal(Number(owner.coins), 5000, "Owner coins must normalize to exactly 5000");

  // 8) Non-owner normalization from owner-level/huge to default
  store.addCoins(userId, 9000); // user coins become >= 5000
  user = ensure(userId, "User");
  assert.equal(Number(user.coins), 5, "Non-owner huge coins must normalize to default 5");

  console.log("PASS: all coin flow tests passed");
  console.log(
    JSON.stringify(
      {
        user: store.getUser(userId),
        owner: store.getUser(ownerId),
        usersJsonPath,
        dbPath
      },
      null,
      2
    )
  );
} finally {
  config.ownerTelegramIds = originalOwnerIds;
}
