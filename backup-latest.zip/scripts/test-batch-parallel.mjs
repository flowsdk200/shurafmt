import fs from "fs";
import path from "path";
import assert from "assert";

const indexPath = path.resolve("/home/riflowsxz/ghs-telegram/src/index.js");
const src = fs.readFileSync(indexPath, "utf8");

const readConstInt = (name) => {
  const re = new RegExp(`const\\s+${name}\\s*=\\s*(\\d+)\\s*;`);
  const m = src.match(re);
  if (!m) throw new Error(`Missing constant: ${name}`);
  return Number.parseInt(m[1], 10);
};

const workerConcurrency = readConstInt("VERIFICATION_WORKER_CONCURRENCY");
const queueLimit = readConstInt("VERIFICATION_QUEUE_LIMIT");

assert.equal(workerConcurrency >= 500, true, "worker concurrency must be >= 500");
assert.equal(queueLimit >= 500, true, "queue limit must be >= 500");

assert.equal(
  src.includes("return enqueueVerificationJob(ctx, inputText);"),
  true,
  "ghs command must enqueue jobs"
);
assert.equal(
  src.includes("await enqueueVerificationJob(ctx, text);"),
  true,
  "text verification input must enqueue jobs"
);

const TOTAL_USERS = 2000;
const queue = Array.from({ length: TOTAL_USERS }, (_, i) => i + 1);
let running = 0;
let done = 0;
let maxParallelObserved = 0;

const fakeWork = () =>
  new Promise((resolve) => {
    setTimeout(resolve, 4);
  });

const finishPromise = new Promise((resolve) => {
  const pump = () => {
    while (running < workerConcurrency && queue.length > 0) {
      queue.shift();
      running += 1;
      if (running > maxParallelObserved) maxParallelObserved = running;

      fakeWork()
        .catch(() => {})
        .finally(() => {
          running -= 1;
          done += 1;
          if (done === TOTAL_USERS) {
            resolve();
          } else {
            pump();
          }
        });
    }
  };

  pump();
});

await finishPromise;

assert.equal(done, TOTAL_USERS, "all simulated jobs must complete");
assert.equal(maxParallelObserved >= 500, true, "max parallel observed must be >= 500");

console.log("PASS: batch/parallel test passed");
console.log(
  JSON.stringify(
    {
      workerConcurrency,
      queueLimit,
      totalUsers: TOTAL_USERS,
      maxParallelObserved,
      completed: done
    },
    null,
    2
  )
);
