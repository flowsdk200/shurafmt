import assert from "assert";
import fs from "fs";
import os from "os";
import path from "path";
import sql from "mssql";
import config from "../src/config.js";
import SqliteStore from "../src/store/sqliteStore.js";
import SqlServerStore from "../src/store/sqlServerStore.js";

const ENGINE = String(process.env.TEST_DB_ENGINE || config.database?.engine || "sqlite")
  .trim()
  .toLowerCase();
const COST = 5;
const stamp = Date.now();
const ownerId = `e2e_owner_${stamp}`;
const userId = `e2e_user_${stamp}`;
const referredId = `e2e_referred_${stamp}`;
const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "ghs-e2e-"));
const usersJsonPath = path.join(tmpDir, "users.json");

const originalOwnerIds = Array.isArray(config.ownerTelegramIds) ? [...config.ownerTelegramIds] : [];
config.ownerTelegramIds = [ownerId];

const makeUser = (id, firstName) => ({ id, first_name: firstName, username: String(firstName || "").toLowerCase() });

const createStore = async () => {
  if (ENGINE === "sqlserver") {
    const store = new SqlServerStore(config.database?.mssql, usersJsonPath);
    await store.ready;
    return store;
  }
  const dbPath = path.join(tmpDir, "ghs.sqlite");
  return new SqliteStore(dbPath, usersJsonPath);
};

const cleanupSqlServerRows = async (ids) => {
  const cfg = config.database?.mssql || {};
  const pool = new sql.ConnectionPool({
    server: cfg.server,
    port: Number(cfg.port) || 1433,
    database: cfg.database,
    user: cfg.user,
    password: cfg.password,
    options: {
      encrypt: cfg.options?.encrypt !== false,
      trustServerCertificate: Boolean(cfg.options?.trustServerCertificate)
    }
  });
  await pool.connect();
  try {
    const req = pool.request();
    req.input("a", sql.NVarChar(64), ids[0]);
    req.input("b", sql.NVarChar(64), ids[1]);
    req.input("c", sql.NVarChar(64), ids[2]);
    await req.query(`
      DELETE FROM referrals WHERE referred_id IN (@a, @b, @c) OR referrer_id IN (@a, @b, @c);
      DELETE FROM users WHERE user_id IN (@a, @b, @c);
    `);
  } finally {
    await pool.close();
  }
};

const run = async () => {
  const ids = [ownerId, userId, referredId];
  if (ENGINE === "sqlserver") await cleanupSqlServerRows(ids);

  const store = await createStore();

  try {
    await store.ensureUser(makeUser(ownerId, "Owner"));
    await store.ensureUser(makeUser(userId, "User"));
    await store.ensureUser(makeUser(referredId, "Referred"));

    let owner = await store.getUser(ownerId);
    let user = await store.getUser(userId);
    let referred = await store.getUser(referredId);

    assert.equal(Number(owner.coins), 5000, "owner default coins must be 5000");
    assert.equal(Number(user.coins), 5, "user default coins must be 5");
    assert.equal(Number(referred.coins), 5, "referred default coins must be 5");

    const deductInsufficient = await store.deductCoins(userId, COST);
    assert.equal(deductInsufficient, true, "default user coins should pass cost 5 deduction");
    user = await store.getUser(userId);
    assert.equal(Number(user.coins), 0, "coins must become 0 after first deduction");

    await store.addCoins(userId, 10);
    await store.incrementVerifications(userId);
    await store.incrementSuccess(userId);
    const deductApproved = await store.deductCoins(userId, COST);
    assert.equal(deductApproved, true, "approved path must deduct coins");
    user = await store.getUser(userId);
    assert.equal(Number(user.coins), 5, "approved path must leave correct coin balance");

    const beforeRejected = Number(user.coins);
    await store.incrementVerifications(userId);
    await store.incrementFailed(userId);
    user = await store.getUser(userId);
    assert.equal(Number(user.coins), beforeRejected, "rejected path must not deduct coins");

    const applyReferral1 = await store.applyReferral({ referrerId: ownerId, newUserId: referredId });
    const applyReferral2 = await store.applyReferral({ referrerId: ownerId, newUserId: referredId });
    assert.equal(applyReferral1, true, "first referral apply must succeed");
    assert.equal(applyReferral2, false, "duplicate referral apply must fail");

    owner = await store.getUser(ownerId);
    referred = await store.getUser(referredId);
    assert.equal(Number(owner.referrals), 1, "owner referral counter must increase");
    assert.equal(Number(owner.earned), 1, "owner earned counter must increase");
    assert.equal(clean(referred.referred_by), ownerId, "referred user must be linked to owner");

    console.log(`PASS: e2e flow test (${ENGINE})`);
    console.log(JSON.stringify({ engine: ENGINE, ownerId, userId, referredId }, null, 2));
  } finally {
    if (ENGINE === "sqlserver") {
      await cleanupSqlServerRows(ids);
      if (store?.pool?.close) await store.pool.close();
    } else if (store?.db?.close) {
      store.db.close();
    }
    config.ownerTelegramIds = originalOwnerIds;
  }
};

const clean = (v) => String(v || "").trim();

await run();
