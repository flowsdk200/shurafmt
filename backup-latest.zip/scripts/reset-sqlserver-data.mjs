import sql from "mssql";
import config from "../src/config.js";

const clean = (v) => String(v || "").trim();

const cfg = config.database?.mssql || {};
if (!cfg.server || !cfg.database || !cfg.user || !cfg.password) {
  throw new Error("SQL Server config incomplete. Check src/config.js -> database.mssql");
}

const force = process.argv.includes("--yes");
if (!force) {
  console.log("This command is destructive.");
  console.log("Usage: node scripts/reset-sqlserver-data.mjs --yes");
  process.exit(1);
}

const pool = new sql.ConnectionPool({
  server: clean(cfg.server),
  port: Number(cfg.port) || 1433,
  database: clean(cfg.database),
  user: clean(cfg.user),
  password: String(cfg.password || ""),
  options: {
    encrypt: cfg.options?.encrypt !== false,
    trustServerCertificate: Boolean(cfg.options?.trustServerCertificate)
  }
});

const run = async () => {
  await pool.connect();

  await pool.request().batch(`
    IF OBJECT_ID(N'referrals', N'U') IS NOT NULL
    BEGIN
      DELETE FROM referrals;
      DBCC CHECKIDENT ('referrals', RESEED, 0);
    END;

    IF OBJECT_ID(N'users', N'U') IS NOT NULL
    BEGIN
      DELETE FROM users;
    END;
  `);

  const usersCount = (
    await pool.request().query("SELECT COUNT(*) AS n FROM users")
  ).recordset?.[0]?.n;
  const referralsCount = (
    await pool.request().query("SELECT COUNT(*) AS n FROM referrals")
  ).recordset?.[0]?.n;

  console.log(
    JSON.stringify(
      {
        ok: true,
        usersCount: Number(usersCount) || 0,
        referralsCount: Number(referralsCount) || 0
      },
      null,
      2
    )
  );

  await pool.close();
};

await run();
