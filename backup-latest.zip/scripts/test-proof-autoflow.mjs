import fs from "fs";
import path from "path";
import { execFile } from "child_process";
import { promisify } from "util";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "..");
const proofDir = path.join(projectRoot, "proof");
const genproofPath = path.join(proofDir, "genproof.js");
const indexPath = path.join(projectRoot, "src", "index.js");
const addressPath = path.join(proofDir, "address.txt");
const readyPoolDir = path.join(proofDir, "photo-pool", "ready");
const manifestPath = path.join(proofDir, "photo-pool", "manifest.json");
const maleNamePath = path.join(proofDir, "name-male.txt");
const femaleNamePath = path.join(proofDir, "name-female.txt");
const execFileAsync = promisify(execFile);

const fail = (msg) => {
  throw new Error(msg);
};

const readJson = (filePath) => JSON.parse(fs.readFileSync(filePath, "utf8"));
const exists = (filePath) => fs.existsSync(filePath);

const runGenproof = async () => {
  const metaPath = path.join(proofDir, `.meta-test-${Date.now()}-${Math.random().toString(36).slice(2)}.json`);
  try {
    await execFileAsync("node", [genproofPath, "--auto", "--json", "--meta-file", metaPath], {
      cwd: proofDir,
      maxBuffer: 4 * 1024 * 1024
    });
    if (!exists(metaPath)) fail(`Meta file tidak dibuat: ${metaPath}`);
    const meta = readJson(metaPath);
    if (!meta || typeof meta !== "object") fail("Meta JSON invalid.");
    if (!meta.outputPath) fail("Meta missing outputPath.");
    if (!meta.fullName) fail("Meta missing fullName.");
    if (!meta.sourcePhotoPath) fail("Meta missing sourcePhotoPath.");
    if (!exists(meta.outputPath)) fail(`Output proof tidak ditemukan: ${meta.outputPath}`);
    return meta;
  } catch (error) {
    const stderr = String(error?.stderr || "").trim();
    const stdout = String(error?.stdout || "").trim();
    fail(`Gagal jalankan genproof.js: ${stderr || stdout || error.message}`);
  } finally {
    if (exists(metaPath)) fs.unlinkSync(metaPath);
  }
};

const assertProofPng = (proofPath) => {
  const buf = fs.readFileSync(proofPath);
  if (buf.length < 8) fail("Ukuran file proof terlalu kecil.");
  const pngSig = "89504e470d0a1a0a";
  if (buf.subarray(0, 8).toString("hex") !== pngSig) {
    fail("File proof bukan PNG valid.");
  }
};

const assertAddressData = () => {
  if (!exists(addressPath)) fail(`address.txt tidak ditemukan: ${addressPath}`);
  const lines = fs
    .readFileSync(addressPath, "utf8")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => /^\d+\.\s+.+/.test(line));
  if (lines.length < 100) fail(`Baris address terlalu sedikit: ${lines.length}`);
};

const assertPoolReadyData = () => {
  if (!exists(readyPoolDir)) fail(`Folder pool ready tidak ditemukan: ${readyPoolDir}`);
  const files = fs
    .readdirSync(readyPoolDir)
    .filter((name) => /\.(jpg|jpeg|png|webp)$/i.test(name));
  if (!files.length) fail(`Folder pool ready kosong: ${readyPoolDir}`);
};

const assertPoolManifestData = () => {
  if (!exists(manifestPath)) fail(`Manifest pool tidak ditemukan: ${manifestPath}`);
  const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
  if (!Array.isArray(manifest) || !manifest.length) fail("Manifest pool kosong/invalid.");
  for (const item of manifest) {
    const file = String(item?.file || "").trim();
    const gender = String(item?.gender || "").trim().toLowerCase();
    if (!file) fail("Manifest item missing file.");
    if (!["male", "female"].includes(gender)) fail(`Manifest gender invalid untuk file ${file}.`);
    const abs = path.join(readyPoolDir, file);
    if (!exists(abs)) fail(`File manifest tidak ditemukan di ready pool: ${abs}`);
  }
};

const assertGenderNameFiles = () => {
  if (!exists(maleNamePath)) fail("name-male.txt tidak ditemukan.");
  if (!exists(femaleNamePath)) fail("name-female.txt tidak ditemukan.");
  const maleRaw = fs.readFileSync(maleNamePath, "utf8");
  const femaleRaw = fs.readFileSync(femaleNamePath, "utf8");
  if (!maleRaw.trim()) fail("name-male.txt kosong.");
  if (!femaleRaw.trim()) fail("name-female.txt kosong.");
};

const assertIndexWiring = () => {
  const src = fs.readFileSync(indexPath, "utf8");
  const iGenerate = src.indexOf("const proofGenerated = await generateProofFromGenProof();");
  const iProfile = src.indexOf("await github.updateProfileName(session, profile.fullName);");
  const iSubmit = src.indexOf("await github.submitPhotoProof(session, {");
  const iSubmitPath = src.indexOf("idCardPath: proofGenerated.proofPath");
  const iDeleteAfterSubmit = src.indexOf("fs.unlinkSync(proofGenerated.proofPath);");
  const iFinallyCleanup = src.indexOf("const cleanupCandidates = [generatedProofPath, defaultGeneratedProofPath]");
  const iDefaultOutputConst = src.indexOf("const defaultGeneratedProofPath = path.resolve(proofDir, \"idcard-output.png\");");

  if (iGenerate < 0) fail("Wiring missing: generateProofFromGenProof call.");
  if (iProfile < 0) fail("Wiring missing: updateProfileName call.");
  if (iSubmit < 0) fail("Wiring missing: submitPhotoProof call.");
  if (iSubmitPath < 0) fail("Wiring missing: submitPhotoProof idCardPath.");
  if (iDeleteAfterSubmit < 0) fail("Wiring missing: delete proof after submit.");
  if (iFinallyCleanup < 0) fail("Wiring missing: final cleanup block.");
  if (iDefaultOutputConst < 0) fail("Wiring missing: default generated proof path const.");
  if (!(iGenerate < iProfile && iProfile < iSubmit)) {
    fail("Urutan flow salah: generate -> profile -> submit.");
  }
};

const assertGenproofPoolWiring = () => {
  const src = fs.readFileSync(genproofPath, "utf8");
  if (src.indexOf("pickRandomPhotoFromPool") < 0) fail("Wiring missing: random photo pool selector.");
  if (src.indexOf("PROOF_PHOTO_POOL_DIR") < 0) fail("Wiring missing: PROOF_PHOTO_POOL_DIR config.");
  if (src.indexOf("pickPhotoFromManifest") < 0) fail("Wiring missing: manifest photo selector.");
  if (src.indexOf("NAME_MALE_FILE") < 0 || src.indexOf("NAME_FEMALE_FILE") < 0) {
    fail("Wiring missing: gender name file config.");
  }
};

const main = async () => {
  if (!exists(genproofPath)) fail(`genproof.js tidak ditemukan: ${genproofPath}`);
  assertAddressData();
  assertPoolReadyData();
  assertPoolManifestData();
  assertGenderNameFiles();
  assertIndexWiring();
  assertGenproofPoolWiring();

  const meta1 = await runGenproof();
  if (path.basename(meta1.outputPath) !== "idcard-output.png") {
    fail(`Nama output bukan idcard-output.png, dapat: ${path.basename(meta1.outputPath)}`);
  }
  if (meta1.fullName.trim().split(/\s+/).length < 2) {
    fail(`Nama proof kurang dari 2 kata: "${meta1.fullName}"`);
  }
  if (!String(meta1.sourcePhotoPath).includes(path.join("photo-pool", "ready"))) {
    fail(`Source photo bukan dari pool ready: ${meta1.sourcePhotoPath}`);
  }
  if (meta1.sourcePhotoMode !== "pool_manifest") {
    fail(`Mode source photo tidak valid: ${meta1.sourcePhotoMode}`);
  }
  if (!meta1.sourceNameFile) {
    fail("Meta missing sourceNameFile.");
  }
  if (!meta1.sourceGender) {
    fail("Mode manifest harus punya sourceGender.");
  }
  if (!["male", "female"].includes(String(meta1.sourceGender))) {
    fail(`Gender source tidak valid: ${meta1.sourceGender}`);
  }
  if (!String(meta1.sourceNameFile).includes(`name-${meta1.sourceGender}.txt`)) {
    fail(`Name file tidak sinkron dengan gender ${meta1.sourceGender}: ${meta1.sourceNameFile}`);
  }
  assertProofPng(meta1.outputPath);

  fs.unlinkSync(meta1.outputPath);
  if (exists(meta1.outputPath)) fail("Cleanup proof gagal (file masih ada).");

  const meta2 = await runGenproof();
  if (!exists(meta2.outputPath)) fail("Re-generate proof gagal setelah cleanup.");
  assertProofPng(meta2.outputPath);
  fs.unlinkSync(meta2.outputPath);
  if (exists(meta2.outputPath)) fail("Cleanup proof akhir gagal (file masih ada).");

  console.log("PASS: proof autoflow checks passed");
  console.log(`- output(cleaned): ${meta2.outputPath}`);
  console.log(`- name: ${meta2.fullName}`);
};

try {
  await main();
} catch (error) {
  console.error(`FAIL: ${error.message}`);
  process.exit(1);
}
