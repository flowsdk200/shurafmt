import fs from "fs";
import config from "../src/config.js";
import SqliteStore from "../src/store/sqliteStore.js";

const usage = () => {
  console.log("This command is destructive.");
  console.log("Usage: node scripts/reset-sqlite-data.mjs --yes [--clear-json]");
};

const force = process.argv.includes("--yes");
const clearJson = process.argv.includes("--clear-json");

if (!force) {
  usage();
  process.exit(1);
}

const db = new SqliteStore(config.storage.sqliteFile, config.storage.usersJsonFile);

try {
  db.db.exec("BEGIN");
  db.db.prepare("DELETE FROM referrals").run();
  db.db.prepare("DELETE FROM users").run();
  db.db.prepare("DELETE FROM sqlite_sequence WHERE name = 'referrals'").run();
  db.db.exec("COMMIT");

  if (clearJson && config.storage?.usersJsonFile) {
    const usersJsonPath = config.storage.usersJsonFile;
    const dir = usersJsonPath.replace(/\/[^/]*$/, "");
    if (dir && !fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(usersJsonPath, JSON.stringify({ users: {} }, null, 2));
  }

  const usersCount = Number(db.db.prepare("SELECT COUNT(*) AS n FROM users").get()?.n || 0);
  const referralsCount = Number(db.db.prepare("SELECT COUNT(*) AS n FROM referrals").get()?.n || 0);

  console.log(
    JSON.stringify(
      {
        ok: true,
        sqliteFile: config.storage.sqliteFile,
        usersJsonFile: config.storage.usersJsonFile,
        usersCount,
        referralsCount,
        jsonCleared: clearJson
      },
      null,
      2
    )
  );
} catch (e) {
  try {
    db.db.exec("ROLLBACK");
  } catch {
    // ignore rollback errors
  }
  throw e;
} finally {
  db.db.close();
}
