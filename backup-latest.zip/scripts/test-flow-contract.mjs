import fs from "fs";
import path from "path";

const indexPath = path.resolve("/home/riflowsxz/ghs-telegram/src/index.js");
const src = fs.readFileSync(indexPath, "utf8");

const assertHas = (snippet, label) => {
  if (!src.includes(snippet)) {
    throw new Error(`Missing flow contract: ${label}`);
  }
};

const assertOrder = (a, b, label) => {
  const ia = src.indexOf(a);
  const ib = src.indexOf(b);
  if (ia < 0 || ib < 0 || ia >= ib) {
    throw new Error(`Order contract failed: ${label}`);
  }
};

const assertHasAfter = (snippet, fromSnippet, label) => {
  const from = src.indexOf(fromSnippet);
  const idx = from >= 0 ? src.indexOf(snippet, from) : -1;
  if (idx < 0) {
    throw new Error(`Missing flow contract: ${label}`);
  }
  return idx;
};

assertHas("• Stage: signing in", "stage signing in");
assertHas("await github.loginWith2fa(session", "loginWith2fa call");
assertOrder("• Stage: signing in", "await github.loginWith2fa(session", "signing stage before login call");

assertHas("• Stage: eligibility check", "stage eligibility check");
assertHas("await github.checkAccountAgeAtLeastDays(session, MIN_ACCOUNT_AGE_DAYS)", "age check call");
assertOrder("• Stage: eligibility check", "await github.checkAccountAgeAtLeastDays(session, MIN_ACCOUNT_AGE_DAYS)", "eligibility stage before age check");

assertHas("if (!ageCheck.ok)", "age check rejection branch");
assertHas("await db.incrementFailed(userId);", "age reject increments failed");
assertHas("Your github account was too recently created", "age reject message");
const ageRejectReturnIdx = assertHasAfter("return;", "if (!ageCheck.ok)", "age reject returns early");

assertHas("• Stage: proof generation", "stage proof generation");
assertHas("const proofGenerated = await generateProofFromGenProof();", "proof generation call");
assertOrder("await github.checkAccountAgeAtLeastDays(session, MIN_ACCOUNT_AGE_DAYS)", "const proofGenerated = await generateProofFromGenProof();", "age check before proof generation");
const proofCallIdx = src.indexOf("const proofGenerated = await generateProofFromGenProof();");
if (!(ageRejectReturnIdx < proofCallIdx)) {
  throw new Error("Order contract failed: age reject must return before proof generation");
}

assertHas("await github.updateProfileName(session, profile.fullName);", "profile sync name call");
assertHas("await github.updateBilling(session", "billing update call");
assertOrder("const proofGenerated = await generateProofFromGenProof();", "await github.updateProfileName(session, profile.fullName);", "proof generation before profile sync");

assertHas("await github.submitPhotoProof(session", "submit photo proof call");
assertHas("fs.unlinkSync(proofGenerated.proofPath);", "proof deleted right after submit");
assertOrder("await github.submitPhotoProof(session", "fs.unlinkSync(proofGenerated.proofPath);", "delete proof after submit");

assertHas("if (finalState === \"approved\")", "approved branch exists");
assertHas("await db.incrementSuccess(userId);", "approved increments success");
assertHas("await db.deductCoins(userId, VERIFICATION_COST);", "approved deducts coins");
assertOrder("if (finalState === \"approved\")", "await db.deductCoins(userId, VERIFICATION_COST);", "coin deduction inside approved branch");

assertHas("} else if (finalState === \"rejected\")", "rejected branch exists");
assertHas("• Coins charged: no", "rejected no-charge message");

assertHas("The application is still pending/review", "pending branch exists");

assertHas("activeByUser.add(userId);", "active lock add");
assertHas("activeByUser.delete(userId);", "active lock release");
assertOrder("activeByUser.add(userId);", "activeByUser.delete(userId);", "lock released in finally");

assertHas("const cleanupCandidates = [generatedProofPath, defaultGeneratedProofPath]", "final cleanup candidates");

console.log("PASS: flow contract checks passed");
