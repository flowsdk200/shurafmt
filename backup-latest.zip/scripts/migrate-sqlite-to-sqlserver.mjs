import SqliteStore from "../src/store/sqliteStore.js";
import SqlServerStore from "../src/store/sqlServerStore.js";
import config from "../src/config.js";

const sqlite = new SqliteStore(config.storage.sqliteFile, config.storage.usersJsonFile);
const sqlServer = new SqlServerStore(config.database?.mssql, config.storage.usersJsonFile);

const run = async () => {
  await sqlServer.ready;
  const users = sqlite.db.prepare("SELECT * FROM users ORDER BY user_id ASC").all() || [];

  for (const row of users) {
    const user = {
      id: row.user_id,
      first_name: row.tg_name,
      username: row.tg_username
    };
    await sqlServer.ensureUser(user);

    const req = await sqlServer._request();
    req.input("user_id", row.user_id);
    req.input("tg_name", row.tg_name || "");
    req.input("tg_username", row.tg_username || "");
    req.input("coins", Number(row.coins) || 0);
    req.input("verifications", Number(row.verifications) || 0);
    req.input("success", Number(row.success) || 0);
    req.input("failed", Number(row.failed) || 0);
    req.input("referrals", Number(row.referrals) || 0);
    req.input("earned", Number(row.earned) || 0);
    req.input("referred_by", row.referred_by || "");
    req.input("created_at", Number(row.created_at) || Date.now());
    req.input("updated_at", Number(row.updated_at) || Date.now());
    await req.query(`
      UPDATE users
      SET tg_name=@tg_name,
          tg_username=@tg_username,
          coins=@coins,
          verifications=@verifications,
          success=@success,
          failed=@failed,
          referrals=@referrals,
          earned=@earned,
          referred_by=@referred_by,
          created_at=@created_at,
          updated_at=@updated_at
      WHERE user_id=@user_id
    `);
  }

  const refs = sqlite.db.prepare("SELECT referrer_id, referred_id, created_at FROM referrals ORDER BY id ASC").all() || [];
  for (const ref of refs) {
    const req = await sqlServer._request();
    req.input("referrer_id", ref.referrer_id);
    req.input("referred_id", ref.referred_id);
    req.input("created_at", Number(ref.created_at) || Date.now());
    await req.query(`
      IF NOT EXISTS (SELECT 1 FROM referrals WHERE referred_id = @referred_id)
      INSERT INTO referrals (referrer_id, referred_id, created_at)
      VALUES (@referrer_id, @referred_id, @created_at)
    `);
  }

  await sqlServer._syncUsersToJson();
  console.log(`Migrated users=${users.length}, referrals=${refs.length}`);
};

await run();
