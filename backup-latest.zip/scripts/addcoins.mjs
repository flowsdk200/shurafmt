import config from "../src/config.js";
import SqliteStore from "../src/store/sqliteStore.js";
import SqlServerStore from "../src/store/sqlServerStore.js";

const clean = (v) => String(v || "").trim();

const usage = () => {
  console.log("Usage:");
  console.log("  node scripts/addcoins.mjs <userId> <amount>");
  console.log("  node scripts/addcoins.mjs --user <userId> --amount <amount>");
};

const parseArgs = (argv) => {
  const args = [...argv];
  if (!args.length || args.includes("--help") || args.includes("-h")) {
    usage();
    process.exit(0);
  }

  let userId = "";
  let amountRaw = "";

  const userIdx = args.indexOf("--user");
  const amountIdx = args.indexOf("--amount");
  if (userIdx >= 0 || amountIdx >= 0) {
    userId = clean(userIdx >= 0 ? args[userIdx + 1] : "");
    amountRaw = clean(amountIdx >= 0 ? args[amountIdx + 1] : "");
  } else {
    userId = clean(args[0]);
    amountRaw = clean(args[1]);
  }

  const amount = Number(amountRaw);
  if (!userId || !Number.isFinite(amount) || amount <= 0) {
    usage();
    throw new Error("Invalid arguments. userId required and amount must be > 0.");
  }

  return { userId, amount: Math.floor(amount) };
};

const createStore = async () => {
  const engine = clean(config.database?.engine || "sqlite").toLowerCase();
  if (engine === "sqlserver") {
    const db = new SqlServerStore(config.database?.mssql, config.storage.usersJsonFile);
    await db.ready;
    return { db, engine };
  }

  const db = new SqliteStore(config.storage.sqliteFile, config.storage.usersJsonFile);
  return { db, engine: "sqlite" };
};

const run = async () => {
  const { userId, amount } = parseArgs(process.argv.slice(2));

  const ownerIds = (config.ownerTelegramIds || []).map((x) => String(x));
  const ownerTarget = Number(config.ownerDefaultCoins) || 5000;
  if (ownerIds.includes(String(userId)) && amount > ownerTarget) {
    throw new Error(
      `Target user is owner. Owner coins are normalized to ${ownerTarget}. Increase config.ownerDefaultCoins first.`
    );
  }

  const { db, engine } = await createStore();

  try {
    let user = await db.getUser(userId);
    if (!user) {
      await db.ensureUser({ id: userId, first_name: `user_${userId}`, username: "" });
      user = await db.getUser(userId);
    }

    const beforeCoins = Number(user?.coins) || 0;
    await db.addCoins(userId, amount);
    const after = await db.getUser(userId);
    const afterCoins = Number(after?.coins) || 0;

    console.log(
      JSON.stringify(
        {
          ok: true,
          engine,
          userId,
          beforeCoins,
          added: amount,
          afterCoins
        },
        null,
        2
      )
    );
  } finally {
    if (engine === "sqlserver" && db?.pool?.close) await db.pool.close();
    if (engine === "sqlite" && db?.db?.close) db.db.close();
  }
};

await run();
