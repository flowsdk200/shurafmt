#!/usr/bin/env node
import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import readline from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";

const execFileAsync = promisify(execFile);
const scriptPath = fileURLToPath(import.meta.url);
const scriptDir = path.dirname(scriptPath);
const rawArgs = process.argv.slice(2);
const args = new Set(rawArgs);
const isAutoMode = args.has("--auto");
const isJsonMode = args.has("--json");
const metaFileIndex = rawArgs.indexOf("--meta-file");
const metaFileArg =
  metaFileIndex >= 0 && rawArgs[metaFileIndex + 1] ? String(rawArgs[metaFileIndex + 1]) : "";

function die(message) {
  console.error(`Error: ${message}`);
  process.exit(1);
}

function trim(value) {
  return String(value ?? "").trim();
}

function normalizeSpaces(value) {
  return String(value ?? "")
    .replace(/\s+/g, " ")
    .trim();
}

function firstTwoWords(value) {
  const words = normalizeSpaces(value).split(" ").filter(Boolean);
  if (!words.length) return "";
  return words.slice(0, 2).join(" ");
}

function randRange(min, max) {
  return crypto.randomInt(min, max + 1);
}

function resolveMaybeRelative(value) {
  if (path.isAbsolute(value)) return value;
  return path.join(scriptDir, value);
}

async function fileExists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

const IMAGE_EXTENSIONS = new Set([".jpg", ".jpeg", ".png", ".webp"]);


async function pickRandomPhotoFromPool(poolDir) {
  if (!(await fileExists(poolDir))) return "";
  let entries = [];
  try {
    entries = await fs.readdir(poolDir, { withFileTypes: true });
  } catch {
    return "";
  }

  const files = entries
    .filter((entry) => entry.isFile())
    .map((entry) => path.join(poolDir, entry.name))
    .filter((filePath) => IMAGE_EXTENSIONS.has(path.extname(filePath).toLowerCase()));

  if (!files.length) return "";
  return files[crypto.randomInt(files.length)];
}

function parseManifestEntries(raw) {
  if (!Array.isArray(raw)) return [];
  return raw
    .map((item) => {
      const file = normalizeSpaces(item?.file || "");
      const gender = normalizeSpaces(item?.gender || "").toLowerCase();
      if (!file || !["male", "female"].includes(gender)) return null;
      return { file, gender };
    })
    .filter(Boolean);
}

async function pickPhotoFromManifest({ poolDir, manifestPath }) {
  if (!(await fileExists(manifestPath))) return null;

  let parsed;
  try {
    parsed = JSON.parse(await fs.readFile(manifestPath, "utf8"));
  } catch {
    return null;
  }

  const entries = parseManifestEntries(parsed);
  if (!entries.length) return null;

  const valid = [];
  for (const item of entries) {
    const absPath = path.isAbsolute(item.file) ? item.file : path.join(poolDir, item.file);
    if (!(await fileExists(absPath))) continue;
    if (!IMAGE_EXTENSIONS.has(path.extname(absPath).toLowerCase())) continue;
    valid.push({ path: absPath, file: path.basename(absPath), gender: item.gender });
  }

  if (!valid.length) return null;
  return valid[crypto.randomInt(valid.length)];
}

function parseNameEntries(content) {
  const out = [];
  const lines = String(content).split(/\r?\n/);
  for (const rawLine of lines) {
    const line = rawLine.trim();
    const match = line.match(/^(\d+)\.\s*(.+)$/);
    if (!match) continue;
    const order = match[1];
    const name = normalizeSpaces(match[2]);
    const parts = name.split(" ").filter(Boolean);
    if (parts.length < 2) continue;
    if (!/^[A-Za-z][A-Za-z' -]*[A-Za-z]$/.test(name)) continue;
    out.push({ order, name });
  }
  return out;
}

async function askWithDefault(rl, prompt, defaultValue) {
  try {
    const answer = normalizeSpaces(await rl.question(prompt));
    return answer || defaultValue;
  } catch (error) {
    const message = String(error?.message || "");
    if (message.toLowerCase().includes("readline was closed")) {
      return defaultValue;
    }
    throw error;
  }
}

const runIdCardGen = async ({ fullName, photoInput, outputPath, studentId, validDate }) => {
  const idCardGenPath = resolveMaybeRelative("idcard-gen.js");
  if (!(await fileExists(idCardGenPath))) {
    die(`idcard-gen.js tidak ditemukan: ${idCardGenPath}`);
  }

  const validityForCard = String(validDate || "").replace("-", "\u2010");

  const execArgs = [
    idCardGenPath,
    fullName,
    "--photoPath",
    photoInput,
    "--studentId",
    studentId,
    "--validityEnd",
    validityForCard,
    "--orientation",
    "portrait",
    "--output",
    outputPath
  ];

  try {
    await execFileAsync("node", execArgs, {
      cwd: scriptDir,
      maxBuffer: 8 * 1024 * 1024
    });
  } catch (error) {
    const stderr = trim(error?.stderr);
    const stdout = trim(error?.stdout);
    die(stderr || stdout || error.message);
  }
};

async function main() {
  const nameFile = resolveMaybeRelative(process.env.NAME_FILE || "name.txt");
  const maleNameFile = resolveMaybeRelative(process.env.NAME_MALE_FILE || "name-male.txt");
  const femaleNameFile = resolveMaybeRelative(process.env.NAME_FEMALE_FILE || "name-female.txt");
  const defaultPhotoInput = resolveMaybeRelative(process.env.DEFAULT_PHOTO_INPUT || "PHOTO-INPUT.jpg");
  const defaultPhotoPoolDir = resolveMaybeRelative(process.env.PROOF_PHOTO_POOL_DIR || "photo-pool/ready");
  const defaultPhotoManifestPath = resolveMaybeRelative(
    process.env.PROOF_PHOTO_MANIFEST || "photo-pool/manifest.json"
  );

  let defaultOutputName = normalizeSpaces(process.env.PROOF_OUTPUT_NAME || "idcard-output.png");
  if (!defaultOutputName) defaultOutputName = "idcard-output.png";
  if (!defaultOutputName.includes(".")) defaultOutputName = `${defaultOutputName}.png`;
  const outputPath = path.isAbsolute(defaultOutputName)
    ? defaultOutputName
    : path.join(scriptDir, defaultOutputName);

  const photoPosX = 0;
  const photoPosY = 0;

  const rl = readline.createInterface({ input, output });
  try {
    let photoInput = defaultPhotoInput;
    let photoSourceMode = "default";
    let selectedGender = "";
    let selectedNameFile = nameFile;

    if (isAutoMode) {
      const pickedByManifest = await pickPhotoFromManifest({
        poolDir: defaultPhotoPoolDir,
        manifestPath: defaultPhotoManifestPath
      });

      if (!pickedByManifest) {
        await pickRandomPhotoFromPool(defaultPhotoPoolDir);
        die(`Manifest photo pool kosong/tidak valid: ${defaultPhotoManifestPath}`);
      }

      photoInput = pickedByManifest.path;
      selectedGender = pickedByManifest.gender;
      selectedNameFile = selectedGender === "male" ? maleNameFile : femaleNameFile;
      photoSourceMode = "pool_manifest";
    } else {
      photoInput = await askWithDefault(
        rl,
        `File Foto [default: ${defaultPhotoInput}]: `,
        defaultPhotoInput
      );
      if (!path.isAbsolute(photoInput)) {
        photoInput = path.resolve(process.cwd(), photoInput);
      }
      selectedNameFile = nameFile;
      photoSourceMode = "manual";
    }

    if (!(await fileExists(photoInput))) {
      die(`Foto tidak ketemu: ${photoInput}`);
    }
    if (!(await fileExists(selectedNameFile))) {
      die(`File nama tidak ketemu: ${selectedNameFile}`);
    }

    const nameRaw = await fs.readFile(selectedNameFile, "utf8");
    const entries = parseNameEntries(nameRaw);
    if (!entries.length) {
      die(`Tidak ada data nama valid di ${selectedNameFile}.`);
    }

    const randomEntry = entries[crypto.randomInt(entries.length)];
    const orderNumber = randomEntry.order;
    const fullNameRaw = normalizeSpaces(randomEntry.name);
    if (!orderNumber || !fullNameRaw) {
      die(`Gagal baca data random dari ${selectedNameFile}.`);
    }

    const fullName = firstTwoWords(fullNameRaw);
    if (!fullName) {
      die(`Nama kosong di data untuk nomor ${orderNumber}.`);
    }

    const studentIdPartA = String(randRange(1, 9));
    const studentIdPartB = String(randRange(1, 9));
    const studentId = `202500${studentIdPartA}00${studentIdPartB}`;
    const validDay = String(randRange(1, 28)).padStart(2, "0");
    const validMonth = String(randRange(1, 12)).padStart(2, "0");
    const validDate = `2030/${validMonth}-${validDay}`;

    await runIdCardGen({
      fullName,
      photoInput,
      outputPath,
      studentId,
      validDate
    });

    if (!(await fileExists(outputPath))) {
      die(`Generated proof file not found: ${outputPath}`);
    }

    const result = {
      outputPath,
      orderNumber,
      fullName,
      studentId,
      validDate,
      sourcePhotoPath: photoInput,
      sourcePhotoMode: photoSourceMode,
      sourceGender: selectedGender,
      sourceNameFile: selectedNameFile,
      photoPosX,
      photoPosY
    };

    if (metaFileArg) {
      const metaPath = path.isAbsolute(metaFileArg)
        ? metaFileArg
        : path.resolve(process.cwd(), metaFileArg);
      await fs.mkdir(path.dirname(metaPath), { recursive: true });
      await fs.writeFile(metaPath, JSON.stringify(result), "utf8");
    }

    if (isJsonMode) {
      console.log(JSON.stringify(result));
    } else {
      console.log(`Berhasil. File ada di: ${outputPath}`);
      console.log(`Nomor Data : ${orderNumber}`);
      console.log(`Nama       : ${fullName}`);
      console.log(`Student ID : ${studentId}`);
      console.log(`Valid Until: ${validDate}`);
      console.log(`Photo Source: ${photoSourceMode}`);
      console.log(`Photo Input : ${photoInput}`);
      if (selectedGender) console.log(`Gender      : ${selectedGender}`);
      console.log(`Name File   : ${selectedNameFile}`);
      console.log(`Photo Pos  : X=${photoPosX} Y=${photoPosY}`);
    }
  } finally {
    rl.close();
  }
}

main().catch((error) => {
  die(error?.message || String(error));
});
